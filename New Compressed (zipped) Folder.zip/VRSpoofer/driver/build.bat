@echo off
REM Builds driver_vrspoofer.dll with the MSVC toolchain.
REM SteamVR loads drivers into vrserver.exe, which is MSVC-built, so the driver
REM has to be too - MinGW's C++ ABI will not interop with the OpenVR interfaces.

setlocal enabledelayedexpansion

set "ROOT=%~dp0"
set "OUTDIR=%ROOT%bin\win64"
set "OBJDIR=%ROOT%build"

REM ---- Locate the MSVC environment -------------------------------------------
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (
	echo [build] ERROR: vswhere.exe not found. Install Visual Studio Build Tools
	echo         with the "Desktop development with C++" workload.
	exit /b 1
)

REM Keep this on one line: a caret continuation inside the backquotes makes cmd
REM run the fragments as separate commands.
for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSPATH=%%i"

if not defined VSPATH (
	echo [build] ERROR: no Visual Studio installation with the C++ toolset.
	exit /b 1
)

echo [build] Using MSVC at: %VSPATH%

REM vcvars64.bat shells out to a bare "vswhere" of its own; put the installer
REM directory on PATH so it resolves instead of printing a scary not-recognised.
set "PATH=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer;%PATH%"

call "%VSPATH%\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 (
	echo [build] ERROR: vcvars64.bat failed.
	exit /b 1
)

if not exist "%OUTDIR%" mkdir "%OUTDIR%"
if not exist "%OBJDIR%" mkdir "%OBJDIR%"

REM ---- Compile ---------------------------------------------------------------
REM /MT statically links the CRT so the DLL has no VC++ redistributable
REM dependency - it has to load inside whatever vrserver.exe happens to be.
echo [build] Compiling...
cl /nologo /c ^
   /std:c++17 /EHsc /O2 /MT /W3 /GS /Zi ^
   /DWIN32 /D_WINDOWS /DNDEBUG /D_CRT_SECURE_NO_WARNINGS ^
   /I"%ROOT%openvr" /I"%ROOT%src" ^
   /Fo"%OBJDIR%\\" /Fd"%OBJDIR%\driver_vrspoofer.pdb" ^
   "%ROOT%src\dllmain.cpp" ^
   "%ROOT%src\ServerDriver.cpp" ^
   "%ROOT%src\PropertySpoofer.cpp" ^
   "%ROOT%src\VirtualHmd.cpp" ^
   "%ROOT%src\VirtualController.cpp" ^
   "%ROOT%src\Config.cpp" ^
   "%ROOT%src\Logger.cpp"
if errorlevel 1 (
	echo [build] ERROR: compilation failed.
	exit /b 1
)

REM ---- Link ------------------------------------------------------------------
echo [build] Linking...
link /nologo /DLL /MACHINE:X64 /DEBUG /OPT:REF /OPT:ICF ^
     /OUT:"%OUTDIR%\driver_vrspoofer.dll" ^
     /PDB:"%OUTDIR%\driver_vrspoofer.pdb" ^
     "%OBJDIR%\*.obj" ^
     shell32.lib ole32.lib user32.lib advapi32.lib
if errorlevel 1 (
	echo [build] ERROR: link failed.
	exit /b 1
)

echo [build] OK -^> %OUTDIR%\driver_vrspoofer.dll
endlocal
exit /b 0
