using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Threading;
using VRSpoofer.Models;
using VRSpoofer.Services;

namespace VRSpoofer.ViewModels;

public sealed class MainViewModel : ObservableObject
{
    private readonly DispatcherTimer _poll;
    private DateTime _toastUntil = DateTime.MinValue;

    public MainViewModel()
    {
        Config = ConfigService.Load();
        HookDirtyTracking();

        ApplyCommand        = new RelayCommand(Apply);
        InstallCommand      = new RelayCommand(Install);
        UninstallCommand    = new RelayCommand(Uninstall);
        LaunchSteamVrCommand = new RelayCommand(SteamVrService.LaunchSteamVr);
        OpenFolderCommand   = new RelayCommand(() => SteamVrService.OpenFolder(AppPaths.Root));
        ResetCommand        = new RelayCommand(ResetToDefaults);
        NavigateCommand     = new RelayCommand(p => CurrentPage = Convert.ToInt32(p));
        RefreshLogCommand   = new RelayCommand(() => LogText = StatusService.ReadLogTail());

        ApplyHeadsetPresetCommand = new RelayCommand(p =>
        {
            if (p is DevicePreset preset)
                ApplyHeadsetPreset(preset);
        });

        ApplyControllerPresetCommand = new RelayCommand(p =>
        {
            if (p is PresetCatalogue.ControllerPresetPair pair)
                ApplyControllerPreset(pair);
        });

        _poll = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        _poll.Tick += (_, _) => Refresh();
        _poll.Start();

        Refresh();
        LogText = StatusService.ReadLogTail();
    }

    // ---- data ---------------------------------------------------------------

    public SpoofConfig Config { get; private set; }

    public IReadOnlyList<DevicePreset> HeadsetPresets => PresetCatalogue.Headsets;
    public IReadOnlyList<PresetCatalogue.ControllerPresetPair> ControllerPresets => PresetCatalogue.Controllers;

    public ObservableCollection<LiveDevice> LiveDevices { get; } = new();

    // ---- commands -----------------------------------------------------------

    public RelayCommand ApplyCommand { get; }
    public RelayCommand InstallCommand { get; }
    public RelayCommand UninstallCommand { get; }
    public RelayCommand LaunchSteamVrCommand { get; }
    public RelayCommand OpenFolderCommand { get; }
    public RelayCommand ResetCommand { get; }
    public RelayCommand NavigateCommand { get; }
    public RelayCommand RefreshLogCommand { get; }
    public RelayCommand ApplyHeadsetPresetCommand { get; }
    public RelayCommand ApplyControllerPresetCommand { get; }

    // ---- navigation ---------------------------------------------------------

    private int _currentPage;
    public int CurrentPage
    {
        get => _currentPage;
        set
        {
            if (!Set(ref _currentPage, value))
                return;
            Raise(nameof(IsDashboard));
            Raise(nameof(IsHeadset));
            Raise(nameof(IsControllers));
            Raise(nameof(IsAdvanced));
            Raise(nameof(IsLog));
            if (value == 4)
                LogText = StatusService.ReadLogTail();
        }
    }

    public bool IsDashboard   => CurrentPage == 0;
    public bool IsHeadset     => CurrentPage == 1;
    public bool IsControllers => CurrentPage == 2;
    public bool IsAdvanced    => CurrentPage == 3;
    public bool IsLog         => CurrentPage == 4;

    // ---- mode toggles (radio-style, bound from segmented controls) -----------

    public bool HmdModeOff
    {
        get => Config.HmdMode == "off";
        set { if (value) SetHmdMode("off"); }
    }
    public bool HmdModeOverride
    {
        get => Config.HmdMode == "override";
        set { if (value) SetHmdMode("override"); }
    }
    public bool HmdModeVirtual
    {
        get => Config.HmdMode == "virtual";
        set { if (value) SetHmdMode("virtual"); }
    }

    private void SetHmdMode(string mode)
    {
        if (Config.HmdMode == mode)
            return;
        Config.HmdMode = mode;
        Config.Hmd.Enabled = mode != "off";
        Raise(nameof(HmdModeOff));
        Raise(nameof(HmdModeOverride));
        Raise(nameof(HmdModeVirtual));
        Raise(nameof(NeedsRestartNote));
        MarkDirty();
    }

    public bool ControllerModeOff
    {
        get => Config.ControllerMode == "off";
        set { if (value) SetControllerMode("off"); }
    }
    public bool ControllerModeOverride
    {
        get => Config.ControllerMode == "override";
        set { if (value) SetControllerMode("override"); }
    }
    public bool ControllerModeVirtual
    {
        get => Config.ControllerMode == "virtual";
        set { if (value) SetControllerMode("virtual"); }
    }

    private void SetControllerMode(string mode)
    {
        if (Config.ControllerMode == mode)
            return;
        Config.ControllerMode = mode;
        Config.LeftController.Enabled = mode != "off";
        Config.RightController.Enabled = mode != "off";
        Raise(nameof(ControllerModeOff));
        Raise(nameof(ControllerModeOverride));
        Raise(nameof(ControllerModeVirtual));
        Raise(nameof(NeedsRestartNote));
        MarkDirty();
    }

    /// <summary>
    /// Virtual devices can only be published while the driver initialises, so
    /// switching into or out of Virtual mode needs a SteamVR restart. Renames
    /// inside a mode take effect live.
    /// </summary>
    public bool NeedsRestartNote =>
        (Config.HmdMode == "virtual" || Config.ControllerMode == "virtual") &&
        (Status?.IsLive ?? false) &&
        (Status!.HmdMode != Config.HmdMode || Status.ControllerMode != Config.ControllerMode);

    // ---- live status --------------------------------------------------------

    private DriverStatus? _status;
    public DriverStatus? Status
    {
        get => _status;
        private set
        {
            _status = value;
            Raise();
            Raise(nameof(DriverLive));
            Raise(nameof(DriverStateText));
            Raise(nameof(NeedsRestartNote));
        }
    }

    private bool _driverInstalled;
    public bool DriverInstalled
    {
        get => _driverInstalled;
        private set
        {
            if (!Set(ref _driverInstalled, value))
                return;
            Raise(nameof(InstallStateText));
            Raise(nameof(CanInstall));
            Raise(nameof(InstallButtonText));
        }
    }

    /// <summary>
    /// False when the files on disk are older than the ones baked into this
    /// exe - which is what happens after you rebuild and rerun the app.
    /// </summary>
    private bool _payloadCurrent = true;
    public bool PayloadCurrent
    {
        get => _payloadCurrent;
        private set
        {
            if (!Set(ref _payloadCurrent, value))
                return;
            Raise(nameof(CanInstall));
            Raise(nameof(InstallButtonText));
            Raise(nameof(InstallStateText));
        }
    }

    /// <summary>Installing is also how you refresh a stale payload.</summary>
    public bool CanInstall => !DriverInstalled || !PayloadCurrent;

    public string InstallButtonText =>
        DriverInstalled && !PayloadCurrent ? "Update driver"
        : DriverInstalled ? "Installed"
        : "Install driver";

    private bool _steamVrRunning;
    public bool SteamVrRunning
    {
        get => _steamVrRunning;
        private set { if (Set(ref _steamVrRunning, value)) Raise(nameof(SteamVrStateText)); }
    }

    private bool _steamVrFound;
    public bool SteamVrFound
    {
        get => _steamVrFound;
        private set => Set(ref _steamVrFound, value);
    }

    public bool DriverLive => Status?.IsLive ?? false;

    public string InstallStateText =>
        !DriverInstalled ? "Not installed"
        : PayloadCurrent ? "Installed"
        : "Update available";
    public string SteamVrStateText => !SteamVrFound ? "Not found"
                                    : SteamVrRunning ? "Running" : "Not running";
    public string DriverStateText => DriverLive ? "Loaded in SteamVR"
                                   : DriverInstalled ? "Waiting for SteamVR" : "Not installed";

    private string _steamVrPath = "";
    public string SteamVrPath
    {
        get => _steamVrPath;
        private set => Set(ref _steamVrPath, value);
    }

    private bool _isDirty;
    public bool IsDirty
    {
        get => _isDirty;
        private set { if (Set(ref _isDirty, value)) Raise(nameof(ApplyButtonText)); }
    }

    public string ApplyButtonText => IsDirty ? "Apply to SteamVR" : "Applied";

    private string _toast = "";
    public string Toast
    {
        get => _toast;
        private set { if (Set(ref _toast, value)) Raise(nameof(HasToast)); }
    }
    public bool HasToast => !string.IsNullOrEmpty(Toast);

    private bool _toastIsError;
    public bool ToastIsError
    {
        get => _toastIsError;
        private set => Set(ref _toastIsError, value);
    }

    private string _logText = "";
    public string LogText
    {
        get => _logText;
        private set => Set(ref _logText, value);
    }

    /// <summary>Mirrors edits from the left hand onto the right.</summary>
    private bool _mirrorControllers = true;
    public bool MirrorControllers
    {
        get => _mirrorControllers;
        set => Set(ref _mirrorControllers, value);
    }

    // ---- behaviour ----------------------------------------------------------

    private void Refresh()
    {
        SteamVrPath = SteamVrService.FindSteamVrPath() ?? "";
        SteamVrFound = SteamVrPath.Length > 0;
        SteamVrRunning = SteamVrService.IsSteamVrRunning();
        DriverInstalled = SteamVrService.IsDriverRegistered();
        PayloadCurrent = !DriverInstalled || SteamVrService.IsPayloadCurrent();

        Status = StatusService.Read();

        var devices = (Status?.IsLive == true) ? Status.Devices : new List<LiveDevice>();
        SyncLiveDevices(devices);

        if (HasToast && DateTime.UtcNow > _toastUntil)
            Toast = "";

        if (IsLog)
            LogText = StatusService.ReadLogTail();
    }

    /// <summary>
    /// Replaces the collection contents in place so the list doesn't flicker or
    /// lose scroll position on every one-second poll.
    /// </summary>
    private void SyncLiveDevices(List<LiveDevice> devices)
    {
        if (LiveDevices.Count == devices.Count)
        {
            var identical = true;
            for (var i = 0; i < devices.Count; i++)
            {
                if (LiveDevices[i].Index != devices[i].Index ||
                    LiveDevices[i].DisplayName != devices[i].DisplayName ||
                    LiveDevices[i].Subtitle != devices[i].Subtitle)
                {
                    identical = false;
                    break;
                }
            }
            if (identical)
                return;
        }

        LiveDevices.Clear();
        foreach (var device in devices)
            LiveDevices.Add(device);
    }

    private void Apply()
    {
        try
        {
            // Keep the enabled flags consistent with the modes, in case a preset
            // was applied while the mode was still off.
            Config.Hmd.Enabled = Config.HmdMode != "off";
            Config.LeftController.Enabled = Config.ControllerMode != "off";
            Config.RightController.Enabled = Config.ControllerMode != "off";

            ConfigService.Save(Config);
            IsDirty = false;

            ShowToast(DriverLive
                ? "Applied. SteamVR picks this up within a second."
                : DriverInstalled
                    ? "Saved. It'll take effect next time SteamVR starts."
                    : "Saved - but the driver isn't installed yet. Install it from the Dashboard.");
        }
        catch (Exception ex)
        {
            ShowToast($"Couldn't save: {ex.Message}", isError: true);
        }
    }

    private void Install()
    {
        var result = SteamVrService.Install();
        ShowToast(result.Message, isError: !result.Success);
        if (result.Success)
        {
            ConfigService.Save(Config);
            IsDirty = false;
        }
        Refresh();
    }

    private void Uninstall()
    {
        var result = SteamVrService.Uninstall();
        ShowToast(result.Message, isError: !result.Success);
        Refresh();
    }

    private void ResetToDefaults()
    {
        Config = ConfigService.CreateDefault();
        HookDirtyTracking();
        Raise(nameof(Config));
        Raise(nameof(HmdModeOff));
        Raise(nameof(HmdModeOverride));
        Raise(nameof(HmdModeVirtual));
        Raise(nameof(ControllerModeOff));
        Raise(nameof(ControllerModeOverride));
        Raise(nameof(ControllerModeVirtual));
        Raise(nameof(SelectedHeadsetIconPack));
        Raise(nameof(SelectedControllerIconPack));
        Raise(nameof(SpoofControllerBindings));
        MarkDirty();
        ShowToast("Reset. Press Apply to write it out.");
    }

    // ---- icon packs ---------------------------------------------------------
    // Decoupled from presets: any device name can wear any icon family.

    public IReadOnlyList<HeadsetIconPack> HeadsetIconPacks => IconCatalogue.Headsets;
    public IReadOnlyList<ControllerIconPack> ControllerIconPacks => IconCatalogue.Controllers;

    public HeadsetIconPack? SelectedHeadsetIconPack
    {
        get => IconCatalogue.MatchHeadset(Config.Hmd.Icons);
        set
        {
            if (value is null)
                return;
            Config.Hmd.Icons = value.Icons.Clone();
            Config.Hmd.RaiseAll();
            Raise();
            MarkDirty();
        }
    }

    public ControllerIconPack? SelectedControllerIconPack
    {
        get => IconCatalogue.MatchController(Config.LeftController.Icons);
        set
        {
            if (value is null)
                return;
            Config.LeftController.Icons = value.Left.Clone();
            Config.RightController.Icons = value.Right.Clone();
            Config.LeftController.RaiseAll();
            Config.RightController.RaiseAll();
            Raise();
            MarkDirty();
        }
    }

    /// <summary>One switch for both hands - they always want the same answer.</summary>
    public bool SpoofControllerBindings
    {
        get => Config.LeftController.SpoofBindings;
        set
        {
            Config.LeftController.SpoofBindings = value;
            Config.RightController.SpoofBindings = value;
            Raise();
            MarkDirty();
        }
    }

    private void ApplyHeadsetPreset(DevicePreset preset)
    {
        preset.ApplyToHeadset(Config.Hmd);
        Raise(nameof(SelectedHeadsetIconPack));

        Config.Display.RenderWidth = preset.RenderWidth;
        Config.Display.RenderHeight = preset.RenderHeight;
        Config.Display.WindowWidth = preset.RenderWidth;
        Config.Display.WindowHeight = preset.RenderHeight;
        Config.Display.DisplayFrequency = preset.DisplayFrequency;

        // Picking a headset while the mode is off almost certainly means the
        // user wants it on; Override is the safe choice with real hardware.
        if (Config.HmdMode == "off")
            SetHmdMode("override");

        MarkDirty();
        ShowToast($"Headset set to {preset.Name}. Press Apply.");
    }

    private void ApplyControllerPreset(PresetCatalogue.ControllerPresetPair pair)
    {
        pair.Left.ApplyToController(Config.LeftController, left: true);
        pair.Right.ApplyToController(Config.RightController, left: false);
        Raise(nameof(SelectedControllerIconPack));

        if (Config.ControllerMode == "off")
            SetControllerMode("override");

        MarkDirty();
        ShowToast($"Controllers set to {pair.Name}. Press Apply.");
    }

    private void ShowToast(string message, bool isError = false)
    {
        Toast = message;
        ToastIsError = isError;
        _toastUntil = DateTime.UtcNow.AddSeconds(6);
    }

    // ---- dirty tracking -----------------------------------------------------

    private void HookDirtyTracking()
    {
        void Hook(INotifyPropertyChanged o) => o.PropertyChanged += (_, _) => MarkDirty();

        Hook(Config);
        Hook(Config.Hmd);
        Hook(Config.LeftController);
        Hook(Config.RightController);
        Hook(Config.Display);
        Hook(Config.Hmd.Icons);
        Hook(Config.LeftController.Icons);
        Hook(Config.RightController.Icons);
    }

    private void MarkDirty() => IsDirty = true;
}
