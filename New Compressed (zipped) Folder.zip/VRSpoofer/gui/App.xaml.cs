using System.Windows;
using VRSpoofer.Services;

namespace VRSpoofer;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        AppPaths.EnsureRoot();

        // A crash in a background binding shouldn't silently kill the window.
        DispatcherUnhandledException += (_, args) =>
        {
            MessageBox.Show(
                $"VRSpoofer hit an unexpected error:\n\n{args.Exception.Message}",
                "VRSpoofer", MessageBoxButton.OK, MessageBoxImage.Warning);
            args.Handled = true;
        };
    }
}
