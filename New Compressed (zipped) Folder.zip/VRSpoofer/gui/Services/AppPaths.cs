using System.IO;

namespace VRSpoofer.Services;

/// <summary>
/// Everything lives under %LOCALAPPDATA%\VRSpoofer so neither the app nor the
/// driver ever needs administrator rights.
/// </summary>
public static class AppPaths
{
    public static string Root { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "VRSpoofer");

    /// <summary>Written by the GUI, polled by the driver.</summary>
    public static string ConfigFile => Path.Combine(Root, "config.json");

    /// <summary>Written by the driver, polled by the GUI.</summary>
    public static string StatusFile => Path.Combine(Root, "status.json");

    public static string DriverLog => Path.Combine(Root, "driver.log");

    /// <summary>Where the driver payload is extracted and registered from.</summary>
    public static string DriverDir => Path.Combine(Root, "driver");

    public static void EnsureRoot() => Directory.CreateDirectory(Root);
}
