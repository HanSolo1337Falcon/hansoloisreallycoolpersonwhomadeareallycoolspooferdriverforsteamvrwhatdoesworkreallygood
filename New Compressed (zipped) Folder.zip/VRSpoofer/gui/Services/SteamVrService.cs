using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace VRSpoofer.Services;

public sealed record InstallResult(bool Success, string Message);

/// <summary>
/// Locates SteamVR, and installs the driver the way SteamVR itself sanctions:
/// the payload is extracted to %LOCALAPPDATA% and registered as an external
/// driver, so nothing is ever written into Program Files and no elevation is
/// needed. Uninstalling is the exact inverse.
/// </summary>
public static class SteamVrService
{
    // Embedded payload: logical resource name -> path relative to the driver root.
    private static readonly Dictionary<string, string> Payload = new()
    {
        ["VRSpoofer.Payload.driver_vrspoofer.dll"] =
            Path.Combine("bin", "win64", "driver_vrspoofer.dll"),
        ["VRSpoofer.Payload.driver.vrdrivermanifest"] =
            "driver.vrdrivermanifest",
        ["VRSpoofer.Payload.default.vrsettings"] =
            Path.Combine("resources", "settings", "default.vrsettings"),
        ["VRSpoofer.Payload.vrspoofer_controller_profile.json"] =
            Path.Combine("resources", "input", "vrspoofer_controller_profile.json"),
    };

    // ---- discovery -----------------------------------------------------------

    public static string? FindSteamPath()
    {
        try
        {
            var hkcu = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam")
                ?.GetValue("SteamPath") as string;
            if (!string.IsNullOrWhiteSpace(hkcu))
            {
                var normalised = hkcu.Replace('/', '\\');
                if (Directory.Exists(normalised))
                    return normalised;
            }

            var hklm = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Valve\Steam")
                ?.GetValue("InstallPath") as string;
            if (!string.IsNullOrWhiteSpace(hklm) && Directory.Exists(hklm))
                return hklm;
        }
        catch (Exception)
        {
            // Registry access can fail under odd policies; fall through.
        }

        var guess = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Steam");
        return Directory.Exists(guess) ? guess : null;
    }

    /// <summary>Checks every Steam library, not just the default one.</summary>
    public static string? FindSteamVrPath()
    {
        var steam = FindSteamPath();
        if (steam is null)
            return null;

        var candidates = new List<string> { steam };

        var libraryFolders = Path.Combine(steam, "steamapps", "libraryfolders.vdf");
        if (File.Exists(libraryFolders))
        {
            try
            {
                var text = File.ReadAllText(libraryFolders);
                foreach (Match m in Regex.Matches(text, "\"path\"\\s*\"([^\"]+)\""))
                    candidates.Add(m.Groups[1].Value.Replace("\\\\", "\\"));
            }
            catch (Exception)
            {
                // Malformed vdf - the default library guess still stands.
            }
        }

        foreach (var root in candidates)
        {
            var path = Path.Combine(root, "steamapps", "common", "SteamVR");
            if (Directory.Exists(path))
                return path;
        }
        return null;
    }

    public static string? FindVrPathReg()
    {
        var steamVr = FindSteamVrPath();
        if (steamVr is null)
            return null;

        var exe = Path.Combine(steamVr, "bin", "win64", "vrpathreg.exe");
        return File.Exists(exe) ? exe : null;
    }

    private static string OpenVrPathsFile => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "openvr", "openvrpaths.vrpath");

    // ---- state ---------------------------------------------------------------

    public static bool IsSteamVrRunning() =>
        Process.GetProcessesByName("vrserver").Length > 0 ||
        Process.GetProcessesByName("vrmonitor").Length > 0;

    public static bool IsDriverRegistered()
    {
        try
        {
            if (!File.Exists(OpenVrPathsFile))
                return false;

            using var doc = JsonDocument.Parse(File.ReadAllText(OpenVrPathsFile));
            if (!doc.RootElement.TryGetProperty("external_drivers", out var drivers) ||
                drivers.ValueKind != JsonValueKind.Array)
                return false;

            var target = NormalisePath(AppPaths.DriverDir);
            foreach (var entry in drivers.EnumerateArray())
            {
                if (entry.ValueKind == JsonValueKind.String &&
                    NormalisePath(entry.GetString() ?? "") == target)
                    return true;
            }
        }
        catch (Exception)
        {
            // Unreadable or malformed - treat as not registered.
        }
        return false;
    }

    public static bool IsPayloadCurrent()
    {
        foreach (var (resource, relative) in Payload)
        {
            var target = Path.Combine(AppPaths.DriverDir, relative);
            if (!File.Exists(target))
                return false;

            var embedded = ReadResource(resource);
            if (embedded is null)
                continue;   // nothing to compare against

            if (!Hash(embedded).SequenceEqual(Hash(File.ReadAllBytes(target))))
                return false;
        }
        return true;
    }

    private static string NormalisePath(string path)
    {
        try
        {
            return Path.GetFullPath(path).TrimEnd('\\', '/').ToLowerInvariant();
        }
        catch (Exception)
        {
            return path.Trim().TrimEnd('\\', '/').ToLowerInvariant();
        }
    }

    private static byte[] Hash(byte[] data) => SHA256.HashData(data);

    private static byte[]? ReadResource(string logicalName)
    {
        using var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(logicalName);
        if (stream is null)
            return null;

        using var memory = new MemoryStream();
        stream.CopyTo(memory);
        return memory.ToArray();
    }

    // ---- install / uninstall -------------------------------------------------

    public static InstallResult Install()
    {
        try
        {
            if (IsSteamVrRunning())
            {
                return new InstallResult(false,
                    "SteamVR is running. Close it first - a loaded driver DLL can't be replaced.");
            }

            AppPaths.EnsureRoot();

            foreach (var (resource, relative) in Payload)
            {
                var bytes = ReadResource(resource);
                if (bytes is null)
                {
                    return new InstallResult(false,
                        $"This build is missing its embedded driver payload ({resource}). " +
                        "Rebuild the driver, then rebuild the app.");
                }

                var target = Path.Combine(AppPaths.DriverDir, relative);
                Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                File.WriteAllBytes(target, bytes);
            }

            if (!RegisterWithVrPathReg(out var registerError))
            {
                if (!RegisterByEditingPathsFile())
                    return new InstallResult(false, registerError);
            }

            return new InstallResult(true,
                "Driver installed. Start SteamVR, then press Apply.");
        }
        catch (Exception ex)
        {
            return new InstallResult(false, $"Install failed: {ex.Message}");
        }
    }

    public static InstallResult Uninstall()
    {
        try
        {
            if (IsSteamVrRunning())
            {
                return new InstallResult(false,
                    "SteamVR is running. Close it first, then uninstall.");
            }

            var vrpathreg = FindVrPathReg();
            if (vrpathreg is not null)
                RunVrPathReg(vrpathreg, "removedriver", AppPaths.DriverDir, out _);

            // vrpathreg is picky about path spelling, so make sure the entry is
            // really gone rather than trusting its exit code.
            UnregisterByEditingPathsFile();

            if (Directory.Exists(AppPaths.DriverDir))
                Directory.Delete(AppPaths.DriverDir, recursive: true);

            return new InstallResult(true, "Driver removed. SteamVR is back to normal.");
        }
        catch (Exception ex)
        {
            return new InstallResult(false, $"Uninstall failed: {ex.Message}");
        }
    }

    private static bool RegisterWithVrPathReg(out string error)
    {
        var vrpathreg = FindVrPathReg();
        if (vrpathreg is null)
        {
            error = "Couldn't find vrpathreg.exe - is SteamVR installed?";
            return false;
        }

        if (!RunVrPathReg(vrpathreg, "adddriver", AppPaths.DriverDir, out var output))
        {
            error = $"vrpathreg refused the driver: {output}";
            return false;
        }

        error = "";
        return IsDriverRegistered();
    }

    private static bool RunVrPathReg(string exe, string verb, string path, out string output)
    {
        var psi = new ProcessStartInfo(exe)
        {
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true,
        };
        psi.ArgumentList.Add(verb);
        psi.ArgumentList.Add(path);

        using var process = Process.Start(psi);
        if (process is null)
        {
            output = "could not start vrpathreg";
            return false;
        }

        output = (process.StandardOutput.ReadToEnd() + process.StandardError.ReadToEnd()).Trim();
        process.WaitForExit(10_000);
        return process.HasExited && process.ExitCode == 0;
    }

    /// <summary>
    /// Fallback when vrpathreg isn't usable: openvrpaths.vrpath is plain JSON
    /// in the user's own AppData, and this is the only key we touch.
    /// </summary>
    private static bool RegisterByEditingPathsFile()
    {
        try
        {
            var file = OpenVrPathsFile;
            if (!File.Exists(file))
                return false;

            var node = System.Text.Json.Nodes.JsonNode.Parse(File.ReadAllText(file));
            if (node is null)
                return false;

            var drivers = node["external_drivers"] as System.Text.Json.Nodes.JsonArray;
            if (drivers is null)
            {
                drivers = new System.Text.Json.Nodes.JsonArray();
                node["external_drivers"] = drivers;
            }

            var target = NormalisePath(AppPaths.DriverDir);
            if (drivers.Any(d => NormalisePath(d?.GetValue<string>() ?? "") == target))
                return true;

            drivers.Add(AppPaths.DriverDir);
            File.WriteAllText(file, node.ToJsonString(new JsonSerializerOptions { WriteIndented = true }),
                              new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
            return true;
        }
        catch (Exception)
        {
            return false;
        }
    }

    private static void UnregisterByEditingPathsFile()
    {
        try
        {
            var file = OpenVrPathsFile;
            if (!File.Exists(file))
                return;

            var node = System.Text.Json.Nodes.JsonNode.Parse(File.ReadAllText(file));
            if (node?["external_drivers"] is not System.Text.Json.Nodes.JsonArray drivers)
                return;

            var target = NormalisePath(AppPaths.DriverDir);
            var kept = new System.Text.Json.Nodes.JsonArray();
            var removed = false;

            foreach (var entry in drivers)
            {
                var value = entry?.GetValue<string>() ?? "";
                if (NormalisePath(value) == target)
                {
                    removed = true;
                    continue;
                }
                kept.Add(value);
            }

            if (!removed)
                return;

            node["external_drivers"] = kept;
            File.WriteAllText(file, node.ToJsonString(new JsonSerializerOptions { WriteIndented = true }),
                              new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
        }
        catch (Exception)
        {
            // Best effort - the driver folder is deleted regardless, so a stale
            // entry is inert.
        }
    }

    // ---- actions -------------------------------------------------------------

    public static void LaunchSteamVr()
    {
        try
        {
            Process.Start(new ProcessStartInfo("steam://run/250820") { UseShellExecute = true });
        }
        catch (Exception)
        {
            // Steam not installed or protocol not registered - the status card
            // already tells the user what's missing.
        }
    }

    public static void OpenFolder(string path)
    {
        try
        {
            Directory.CreateDirectory(path);
            Process.Start(new ProcessStartInfo("explorer.exe", $"\"{path}\"") { UseShellExecute = true });
        }
        catch (Exception)
        {
        }
    }
}
