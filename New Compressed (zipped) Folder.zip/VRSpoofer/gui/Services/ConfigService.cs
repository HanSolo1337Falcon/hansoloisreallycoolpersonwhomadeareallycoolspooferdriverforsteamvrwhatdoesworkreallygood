using System.IO;
using System.Text.Json;
using VRSpoofer.Models;

namespace VRSpoofer.Services;

/// <summary>Reads and writes the config.json the driver watches.</summary>
public static class ConfigService
{
    private static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
    };

    public static SpoofConfig Load()
    {
        try
        {
            if (!File.Exists(AppPaths.ConfigFile))
                return CreateDefault();

            var json = File.ReadAllText(AppPaths.ConfigFile);
            var config = JsonSerializer.Deserialize<SpoofConfig>(json, Options);
            return config ?? CreateDefault();
        }
        catch (Exception)
        {
            // A corrupt config shouldn't stop the app from opening; the user can
            // just re-apply. Their old file is left on disk untouched.
            return CreateDefault();
        }
    }

    /// <summary>
    /// Writes to a temp file then moves it into place, so the driver - which
    /// polls this file - never sees a half-written config.
    /// </summary>
    public static void Save(SpoofConfig config)
    {
        AppPaths.EnsureRoot();

        var json = JsonSerializer.Serialize(config, Options);
        var tmp = AppPaths.ConfigFile + ".tmp";

        File.WriteAllText(tmp, json);
        File.Move(tmp, AppPaths.ConfigFile, overwrite: true);
    }

    /// <summary>
    /// A safe starting point: everything off, so installing the driver on its
    /// own changes nothing until the user picks something.
    /// </summary>
    public static SpoofConfig CreateDefault() => new()
    {
        Enabled = true,
        VerboseLog = false,
        ApplyIntervalSeconds = 1.0,
        HmdMode = "off",
        ControllerMode = "off",
    };
}
