using System.IO;
using System.Text.Json;
using VRSpoofer.Models;

namespace VRSpoofer.Services;

/// <summary>Reads the status file the driver writes from inside vrserver.</summary>
public static class StatusService
{
    private static readonly JsonSerializerOptions Options = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
    };

    public static DriverStatus? Read()
    {
        try
        {
            if (!File.Exists(AppPaths.StatusFile))
                return null;

            // The driver writes atomically, but share the handle anyway so a
            // concurrent move never throws here.
            using var stream = new FileStream(AppPaths.StatusFile, FileMode.Open,
                                              FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
            return JsonSerializer.Deserialize<DriverStatus>(stream, Options);
        }
        catch (Exception)
        {
            return null;
        }
    }

    /// <summary>Last N lines of the driver log, newest last.</summary>
    public static string ReadLogTail(int maxLines = 400)
    {
        try
        {
            if (!File.Exists(AppPaths.DriverLog))
                return "No driver log yet.\r\n\r\nInstall the driver and start SteamVR - the driver writes here as soon as it loads.";

            using var stream = new FileStream(AppPaths.DriverLog, FileMode.Open,
                                              FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
            using var reader = new StreamReader(stream);

            var lines = new Queue<string>(maxLines);
            while (reader.ReadLine() is { } line)
            {
                if (lines.Count == maxLines)
                    lines.Dequeue();
                lines.Enqueue(line);
            }
            return string.Join(Environment.NewLine, lines);
        }
        catch (Exception ex)
        {
            return $"Could not read the driver log: {ex.Message}";
        }
    }
}
