using System.Text.Json.Serialization;

namespace VRSpoofer.Models;

/// <summary>One device as SteamVR currently reports it, via the driver.</summary>
public sealed class LiveDevice
{
    public int Index { get; set; }

    /// <summary>ETrackedDeviceClass: 1 HMD, 2 controller, 3 tracker, 4 base station.</summary>
    public int Class { get; set; }

    /// <summary>ETrackedControllerRole: 1 left, 2 right.</summary>
    public int Role { get; set; }

    public string Manufacturer { get; set; } = "";
    public string Model { get; set; } = "";
    public string Serial { get; set; } = "";
    public string RenderModel { get; set; } = "";
    public string TrackingSystem { get; set; } = "";

    /// <summary>Icon paths as SteamVR currently holds them, read back from the
    /// device rather than assumed from what we wrote.</summary>
    public string IconReady { get; set; } = "";
    public string IconOff { get; set; } = "";

    /// <summary>True when this is a virtual device VRSpoofer published itself.</summary>
    public bool Ours { get; set; }

    [JsonIgnore]
    public string ClassName => Class switch
    {
        1 => "Headset",
        2 => Role switch { 1 => "Left controller", 2 => "Right controller", _ => "Controller" },
        3 => "Tracker",
        4 => "Base station",
        5 => "Display redirect",
        _ => "Device",
    };

    [JsonIgnore]
    public string Glyph => Class switch
    {
        1 => "HMD",
        2 => Role switch { 1 => "L", 2 => "R", _ => "C" },
        3 => "TRK",
        4 => "BS",
        _ => "?",
    };

    [JsonIgnore]
    public string DisplayName
    {
        get
        {
            var name = string.Join(' ', new[] { Manufacturer, Model }
                .Where(s => !string.IsNullOrWhiteSpace(s)));
            return string.IsNullOrWhiteSpace(name) ? $"Device {Index}" : name;
        }
    }

    [JsonIgnore]
    public string Subtitle
    {
        get
        {
            var parts = new List<string> { ClassName };
            if (!string.IsNullOrWhiteSpace(Serial)) parts.Add(Serial);
            if (!string.IsNullOrWhiteSpace(TrackingSystem)) parts.Add(TrackingSystem);
            return string.Join("  ·  ", parts);
        }
    }
}

/// <summary>The driver's own view of the world, written every 2 seconds.</summary>
public sealed class DriverStatus
{
    public bool DriverRunning { get; set; }
    public int Pid { get; set; }
    public long Timestamp { get; set; }
    public bool Enabled { get; set; }
    public string HmdMode { get; set; } = "off";
    public string ControllerMode { get; set; } = "off";
    public int DevicesTouched { get; set; }
    public List<LiveDevice> Devices { get; set; } = new();

    /// <summary>
    /// The driver writes driverRunning:false on shutdown, but a hard SteamVR
    /// crash leaves a stale true - so treat an old file as not running.
    /// </summary>
    [JsonIgnore]
    public bool IsFresh =>
        DateTimeOffset.UtcNow.ToUnixTimeSeconds() - Timestamp < 15;

    [JsonIgnore]
    public bool IsLive => DriverRunning && IsFresh;
}
