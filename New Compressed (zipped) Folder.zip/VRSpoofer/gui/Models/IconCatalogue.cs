namespace VRSpoofer.Models;

public sealed class HeadsetIconPack
{
    public required string Name { get; init; }
    public required string Blurb { get; init; }
    public required IconSet Icons { get; init; }
    public override string ToString() => Name;
}

public sealed class ControllerIconPack
{
    public required string Name { get; init; }
    public required string Blurb { get; init; }
    public required IconSet Left { get; init; }
    public required IconSet Right { get; init; }
    public override string ToString() => Name;
}

/// <summary>
/// Every status-icon family present in a stock SteamVR install, addressable
/// independently of the device name. Each family names its states differently
/// and several are missing states entirely, so the builders below are per-style
/// rather than one guessed convention - every filename here was listed from the
/// SteamVR install before being written down.
/// </summary>
public static class IconCatalogue
{
    // ---- headset builders ----------------------------------------------------

    /// <summary>`{driver}/icons/{prefix}_{state}` with standby + standby_alert,
    /// no low-battery art. Used by indexhmd, htc and lighthouse.</summary>
    private static IconSet StatusStyle(string driver, string prefix, bool standbyAlert) => new()
    {
        Off            = $"{{{driver}}}/icons/{prefix}_off.png",
        Searching      = $"{{{driver}}}/icons/{prefix}_searching.gif",
        SearchingAlert = $"{{{driver}}}/icons/{prefix}_searching_alert.gif",
        Ready          = $"{{{driver}}}/icons/{prefix}_ready.png",
        ReadyAlert     = $"{{{driver}}}/icons/{prefix}_ready_alert.png",
        NotReady       = $"{{{driver}}}/icons/{prefix}_error.png",
        Standby        = $"{{{driver}}}/icons/{prefix}_standby.png",
        StandbyAlert   = standbyAlert
                            ? $"{{{driver}}}/icons/{prefix}_standby_alert.png"
                            : $"{{{driver}}}/icons/{prefix}_standby.png",
        AlertLow       = $"{{{driver}}}/icons/{prefix}_ready_alert.png",
    };

    /// <summary>oculus `{prefix}_headset_*`. The older families spell the
    /// searching-alert frame `alert_searching` instead of `searching_alert`.</summary>
    private static IconSet OculusHeadset(string prefix, bool hasSearchingAlert) => new()
    {
        Off            = $"{{oculus}}/icons/{prefix}_headset_off.png",
        Searching      = $"{{oculus}}/icons/{prefix}_headset_searching.gif",
        SearchingAlert = hasSearchingAlert
                            ? $"{{oculus}}/icons/{prefix}_headset_searching_alert.gif"
                            : $"{{oculus}}/icons/{prefix}_headset_alert_searching.gif",
        Ready          = $"{{oculus}}/icons/{prefix}_headset_ready.png",
        ReadyAlert     = $"{{oculus}}/icons/{prefix}_headset_ready_alert.png",
        NotReady       = $"{{oculus}}/icons/{prefix}_headset_error.png",
        Standby        = $"{{oculus}}/icons/{prefix}_headset_standby.png",
        StandbyAlert   = $"{{oculus}}/icons/{prefix}_headset_standby.png",
        AlertLow       = $"{{oculus}}/icons/{prefix}_headset_ready_alert.png",
    };

    /// <summary>vrlink `headset_{key}_*`. No alert or standby art at all, so
    /// those states reuse the closest thing that exists.</summary>
    private static IconSet VrLinkHeadset(string key) => new()
    {
        Off            = $"{{vrlink}}/icons/headset_{key}_off.png",
        Searching      = $"{{vrlink}}/icons/headset_{key}_searching.gif",
        SearchingAlert = $"{{vrlink}}/icons/headset_{key}_searching.gif",
        Ready          = $"{{vrlink}}/icons/headset_{key}_ready.png",
        ReadyAlert     = $"{{vrlink}}/icons/headset_{key}_ready_low.png",
        NotReady       = $"{{vrlink}}/icons/headset_{key}_error.png",
        Standby        = $"{{vrlink}}/icons/headset_{key}_off.png",
        StandbyAlert   = $"{{vrlink}}/icons/headset_{key}_info.png",
        AlertLow       = $"{{vrlink}}/icons/headset_{key}_ready_low.png",
    };

    // ---- controller builders -------------------------------------------------

    /// <summary>indexcontroller: `{hand}_controller_status_*`, handed art.</summary>
    private static IconSet IndexController(bool left)
    {
        var h = left ? "left" : "right";
        return new IconSet
        {
            Off            = $"{{indexcontroller}}/icons/{h}_controller_status_off.png",
            Searching      = $"{{indexcontroller}}/icons/{h}_controller_status_searching.gif",
            SearchingAlert = $"{{indexcontroller}}/icons/{h}_controller_status_searching_alert.gif",
            Ready          = $"{{indexcontroller}}/icons/{h}_controller_status_ready.png",
            ReadyAlert     = $"{{indexcontroller}}/icons/{h}_controller_status_ready_alert.png",
            NotReady       = $"{{indexcontroller}}/icons/{h}_controller_status_error.png",
            Standby        = $"{{indexcontroller}}/icons/{h}_controller_status_off.png",
            StandbyAlert   = $"{{indexcontroller}}/icons/{h}_controller_status_ready_alert.png",
            AlertLow       = $"{{indexcontroller}}/icons/{h}_controller_status_ready_low.png",
        };
    }

    /// <summary>htc and lighthouse ship one un-handed controller set.</summary>
    private static IconSet UnhandedController(string driver) => new()
    {
        Off            = $"{{{driver}}}/icons/controller_status_off.png",
        Searching      = $"{{{driver}}}/icons/controller_status_searching.gif",
        SearchingAlert = $"{{{driver}}}/icons/controller_status_searching_alert.gif",
        Ready          = $"{{{driver}}}/icons/controller_status_ready.png",
        ReadyAlert     = $"{{{driver}}}/icons/controller_status_ready_alert.png",
        NotReady       = $"{{{driver}}}/icons/controller_status_error.png",
        Standby        = $"{{{driver}}}/icons/controller_status_off.png",
        StandbyAlert   = $"{{{driver}}}/icons/controller_status_ready_alert.png",
        AlertLow       = $"{{{driver}}}/icons/controller_status_ready_low.png",
    };

    /// <summary>oculus `{prefix}_{hand}_controller_*`.</summary>
    private static IconSet OculusController(string prefix, bool left)
    {
        var h = left ? "left" : "right";
        return new IconSet
        {
            Off            = $"{{oculus}}/icons/{prefix}_{h}_controller_off.png",
            Searching      = $"{{oculus}}/icons/{prefix}_{h}_controller_searching.gif",
            SearchingAlert = $"{{oculus}}/icons/{prefix}_{h}_controller_searching_alert.gif",
            Ready          = $"{{oculus}}/icons/{prefix}_{h}_controller_ready.png",
            ReadyAlert     = $"{{oculus}}/icons/{prefix}_{h}_controller_ready_alert.png",
            NotReady       = $"{{oculus}}/icons/{prefix}_{h}_controller_error.png",
            Standby        = $"{{oculus}}/icons/{prefix}_{h}_controller_off.png",
            StandbyAlert   = $"{{oculus}}/icons/{prefix}_{h}_controller_ready_alert.png",
            AlertLow       = $"{{oculus}}/icons/{prefix}_{h}_controller_ready_low.png",
        };
    }

    /// <summary>vrlink `{hand}_{key}_*`. hasError is false for the hand-tracking
    /// set, which ships no error frame.</summary>
    private static IconSet VrLinkController(string key, bool left, bool hasError = true)
    {
        var h = left ? "left" : "right";
        var error = hasError
            ? $"{{vrlink}}/icons/{h}_{key}_error.png"
            : $"{{vrlink}}/icons/{h}_{key}_off.png";
        var low = hasError
            ? $"{{vrlink}}/icons/{h}_{key}_ready_low.png"
            : $"{{vrlink}}/icons/{h}_{key}_ready.png";

        return new IconSet
        {
            Off            = $"{{vrlink}}/icons/{h}_{key}_off.png",
            Searching      = $"{{vrlink}}/icons/{h}_{key}_searching.gif",
            SearchingAlert = $"{{vrlink}}/icons/{h}_{key}_searching.gif",
            Ready          = $"{{vrlink}}/icons/{h}_{key}_ready.png",
            ReadyAlert     = low,
            NotReady       = error,
            Standby        = $"{{vrlink}}/icons/{h}_{key}_off.png",
            StandbyAlert   = $"{{vrlink}}/icons/{h}_{key}_info.png",
            AlertLow       = low,
        };
    }

    /// <summary>
    /// Applies a fix-up to a built set. Valve's icon folders are not internally
    /// consistent - a couple of families are missing a frame on one hand only,
    /// or name it differently - so those cases are patched explicitly rather
    /// than pretending a naming rule covers them.
    /// </summary>
    private static IconSet With(IconSet set, Action<IconSet> patch)
    {
        patch(set);
        return set;
    }

    /// <summary>gamepad ships no searching frame.</summary>
    private static IconSet Gamepad() => new()
    {
        Off            = "{gamepad}/icons/gamepad_status_off.png",
        Searching      = "{gamepad}/icons/gamepad_status_off.png",
        SearchingAlert = "{gamepad}/icons/gamepad_status_off.png",
        Ready          = "{gamepad}/icons/gamepad_status_ready.png",
        ReadyAlert     = "{gamepad}/icons/gamepad_status_ready_alert.png",
        NotReady       = "{gamepad}/icons/gamepad_status_error.png",
        Standby        = "{gamepad}/icons/gamepad_status_standby.png",
        StandbyAlert   = "{gamepad}/icons/gamepad_status_ready_alert.png",
        AlertLow       = "{gamepad}/icons/gamepad_status_ready_low.png",
    };

    // ---- the catalogue -------------------------------------------------------

    public static readonly IReadOnlyList<HeadsetIconPack> Headsets = new List<HeadsetIconPack>
    {
        new() { Name = "Valve Index",        Blurb = "Index visor",             Icons = StatusStyle("indexhmd", "headset_status", true) },
        new() { Name = "Lighthouse generic", Blurb = "Neutral tracked visor",   Icons = StatusStyle("lighthouse", "headset_status", true) },
        new() { Name = "HTC Vive",           Blurb = "Original Vive",           Icons = StatusStyle("htc", "headset_status", true) },
        new() { Name = "Vive Pro",           Blurb = "Blue Vive Pro visor",     Icons = StatusStyle("htc", "vivepro_status", false) },
        new() { Name = "Meta Quest",         Blurb = "Quest 2 / 3 silhouette",  Icons = OculusHeadset("quest", true) },
        new() { Name = "Oculus Quest 1",     Blurb = "Original Quest",          Icons = OculusHeadset("cb", true) },
        new() { Name = "Oculus Rift S",      Blurb = "Rift S halo",             Icons = OculusHeadset("rifts", false) },
        new() { Name = "Oculus Rift CV1",    Blurb = "2016 Rift",               Icons = OculusHeadset("cv1", false) },
        new() { Name = "Oculus DK2",         Blurb = "Dev Kit 2",               Icons = OculusHeadset("dk2", false) },
        new() { Name = "Oculus DK1",         Blurb = "Dev Kit 1",               Icons = OculusHeadset("dk1", false) },
        new() { Name = "Steam Frame",        Blurb = "Valve standalone",        Icons = VrLinkHeadset("steamframe") },
        new() { Name = "Pico 4",             Blurb = "Pico pancake visor",      Icons = VrLinkHeadset("pico4") },
        new() { Name = "Vive Focus Vision",  Blurb = "HTC standalone",          Icons = VrLinkHeadset("vivefocusvision") },
    };

    public static readonly IReadOnlyList<ControllerIconPack> Controllers = new List<ControllerIconPack>
    {
        new() { Name = "Index Knuckles",     Blurb = "Handed Index grips",
                Left = IndexController(true),               Right = IndexController(false) },
        new() { Name = "Vive Wand",          Blurb = "Trackpad wand",
                Left = UnhandedController("htc"),           Right = UnhandedController("htc") },
        new() { Name = "Lighthouse generic", Blurb = "Neutral wand",
                Left = UnhandedController("lighthouse"),    Right = UnhandedController("lighthouse") },
        new() { Name = "Quest Touch",        Blurb = "Ringed Touch",
                Left = OculusController("cb", true),        Right = OculusController("cb", false) },
        new() { Name = "Rift S Touch",       Blurb = "Rift S Touch",
                Left = OculusController("rifts", true),     Right = OculusController("rifts", false) },
        new() { Name = "Rift CV1 Touch",     Blurb = "Half-moon Touch",
                Left = OculusController("cv1", true),       Right = OculusController("cv1", false) },
        new() { Name = "Pico 4",             Blurb = "Pico ringed pair",
                Left = VrLinkController("pico4", true),     Right = VrLinkController("pico4", false) },
        new() { Name = "Pico 4 Ultra",       Blurb = "Pico ring-less pair",
                Left = VrLinkController("pico4u", true),    Right = VrLinkController("pico4u", false) },
        new() { Name = "Vive Focus",         Blurb = "HTC standalone pair",
                // The left hand ships only a _2x searching frame, so fall back
                // to the static off art rather than a path that doesn't exist.
                Left = With(VrLinkController("vivefocusvision", true), s =>
                {
                    s.Searching = "{vrlink}/icons/left_vivefocusvision_off.png";
                    s.SearchingAlert = s.Searching;
                }),
                Right = VrLinkController("vivefocusvision", false) },
        new() { Name = "Hand tracking",      Blurb = "Bare hands",
                Left = VrLinkController("handtracking", true, hasError: false),
                // Right hand names its info frame ready_info; the left calls it info.
                Right = With(VrLinkController("handtracking", false, hasError: false), s =>
                    s.StandbyAlert = "{vrlink}/icons/right_handtracking_ready_info.png") },
        new() { Name = "Gamepad",            Blurb = "Controller pad",
                Left = Gamepad(),                           Right = Gamepad() },
    };

    public static HeadsetIconPack? FindHeadset(string? name) =>
        Headsets.FirstOrDefault(p => p.Name == name);

    public static ControllerIconPack? FindController(string? name) =>
        Controllers.FirstOrDefault(p => p.Name == name);

    /// <summary>
    /// Reverse lookup so the picker can show what a loaded config is already
    /// using. The ready-state path is unique per family, so it identifies one.
    /// </summary>
    public static HeadsetIconPack? MatchHeadset(IconSet icons) =>
        Headsets.FirstOrDefault(p => p.Icons.Ready == icons.Ready);

    public static ControllerIconPack? MatchController(IconSet left) =>
        Controllers.FirstOrDefault(p => p.Left.Ready == left.Ready);
}
