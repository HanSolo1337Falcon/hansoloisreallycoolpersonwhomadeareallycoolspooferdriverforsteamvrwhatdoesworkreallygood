using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace VRSpoofer.Models;

/// <summary>
/// Base for anything the UI binds to. Kept deliberately tiny so the config
/// objects can double as view models and the live preview updates as you type.
/// </summary>
public abstract class ObservableObject : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;

    protected void Raise([CallerMemberName] string? name = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

    protected bool Set<T>(ref T field, T value, [CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
            return false;
        field = value;
        Raise(name);
        return true;
    }
}

/// <summary>Named status icons SteamVR shows for a device.</summary>
public sealed class IconSet : ObservableObject
{
    private string _off = "", _searching = "", _searchingAlert = "", _ready = "",
                   _readyAlert = "", _notReady = "", _standby = "", _standbyAlert = "", _alertLow = "";

    public string Off            { get => _off;            set => Set(ref _off, value); }
    public string Searching      { get => _searching;      set => Set(ref _searching, value); }
    public string SearchingAlert { get => _searchingAlert; set => Set(ref _searchingAlert, value); }
    public string Ready          { get => _ready;          set => Set(ref _ready, value); }
    public string ReadyAlert     { get => _readyAlert;     set => Set(ref _readyAlert, value); }
    public string NotReady       { get => _notReady;       set => Set(ref _notReady, value); }
    public string Standby        { get => _standby;        set => Set(ref _standby, value); }
    public string StandbyAlert   { get => _standbyAlert;   set => Set(ref _standbyAlert, value); }
    public string AlertLow       { get => _alertLow;       set => Set(ref _alertLow, value); }

    public IconSet Clone() => new()
    {
        Off = Off, Searching = Searching, SearchingAlert = SearchingAlert,
        Ready = Ready, ReadyAlert = ReadyAlert, NotReady = NotReady,
        Standby = Standby, StandbyAlert = StandbyAlert, AlertLow = AlertLow
    };
}

/// <summary>One device's spoofed identity. Empty strings mean "leave alone".</summary>
public sealed class DeviceSpoof : ObservableObject
{
    private bool _enabled;
    private string _manufacturer = "", _modelNumber = "", _serialNumber = "", _renderModel = "",
                   _trackingSystem = "", _registeredDeviceType = "", _controllerType = "",
                   _inputProfilePath = "", _hardwareRevision = "", _driverVersion = "";
    private bool _spoofSerial;

    public bool Enabled { get => _enabled; set => Set(ref _enabled, value); }

    public string Manufacturer         { get => _manufacturer;         set => Set(ref _manufacturer, value); }
    public string ModelNumber          { get => _modelNumber;          set => Set(ref _modelNumber, value); }
    public string SerialNumber         { get => _serialNumber;         set => Set(ref _serialNumber, value); }
    public string RenderModel          { get => _renderModel;          set => Set(ref _renderModel, value); }
    public string TrackingSystem       { get => _trackingSystem;       set => Set(ref _trackingSystem, value); }
    public string RegisteredDeviceType { get => _registeredDeviceType; set => Set(ref _registeredDeviceType, value); }
    public string ControllerType       { get => _controllerType;       set => Set(ref _controllerType, value); }
    public string InputProfilePath     { get => _inputProfilePath;     set => Set(ref _inputProfilePath, value); }
    public string HardwareRevision     { get => _hardwareRevision;     set => Set(ref _hardwareRevision, value); }
    public string DriverVersion        { get => _driverVersion;        set => Set(ref _driverVersion, value); }

    /// <summary>
    /// Serial numbers are bound to a device index for the life of a SteamVR
    /// session, so rewriting one on a real device is opt-in.
    /// </summary>
    public bool SpoofSerial { get => _spoofSerial; set => Set(ref _spoofSerial, value); }

    /// <summary>
    /// Whether to rewrite controller type and input profile on a real device.
    /// Those two pick the binding file, so changing them on hardware that
    /// publishes different input components breaks buttons and removes the
    /// dashboard laser. Off by default.
    /// </summary>
    private bool _spoofBindings;
    public bool SpoofBindings { get => _spoofBindings; set => Set(ref _spoofBindings, value); }

    public IconSet Icons { get; set; } = new();

    // Raw ETrackedDeviceProperty id -> value, for anything the structured
    // fields above don't cover.
    public Dictionary<string, string> ExtraStrings { get; set; } = new();
    public Dictionary<string, double> ExtraFloats  { get; set; } = new();
    public Dictionary<string, int>    ExtraInts    { get; set; } = new();
    public Dictionary<string, bool>   ExtraBools   { get; set; } = new();

    /// <summary>Text shown in the app's SteamVR status preview.</summary>
    [JsonIgnore]
    public string DisplayLabel
    {
        get
        {
            var name = string.Join(' ', new[] { Manufacturer, ModelNumber }
                .Where(s => !string.IsNullOrWhiteSpace(s)));
            return string.IsNullOrWhiteSpace(name) ? "(unchanged)" : name;
        }
    }

    /// <summary>
    /// Tells the UI every field may have changed. Used after a preset is
    /// applied, which writes the backing fields in bulk.
    /// </summary>
    public void RaiseAll()
    {
        Raise(string.Empty);          // WPF treats "" as "all properties"
        Raise(nameof(DisplayLabel));
    }

    public void CopyFrom(DeviceSpoof other)
    {
        Manufacturer = other.Manufacturer;
        ModelNumber = other.ModelNumber;
        SerialNumber = other.SerialNumber;
        RenderModel = other.RenderModel;
        TrackingSystem = other.TrackingSystem;
        RegisteredDeviceType = other.RegisteredDeviceType;
        ControllerType = other.ControllerType;
        InputProfilePath = other.InputProfilePath;
        HardwareRevision = other.HardwareRevision;
        DriverVersion = other.DriverVersion;
        Icons = other.Icons.Clone();
        Raise(nameof(Icons));
        Raise(nameof(DisplayLabel));
    }
}

/// <summary>Display characteristics used only by the virtual HMD.</summary>
public sealed class VirtualDisplay : ObservableObject
{
    private int _windowX, _windowY;
    private int _windowWidth = 2064, _windowHeight = 2208;
    private int _renderWidth = 2064, _renderHeight = 2208;
    private double _displayFrequency = 90.0;
    private double _secondsFromVsyncToPhotons = 0.011;
    private double _ipd = 0.063;
    private bool _isOnDesktop;

    public int WindowX      { get => _windowX;      set => Set(ref _windowX, value); }
    public int WindowY      { get => _windowY;      set => Set(ref _windowY, value); }
    public int WindowWidth  { get => _windowWidth;  set => Set(ref _windowWidth, value); }
    public int WindowHeight { get => _windowHeight; set => Set(ref _windowHeight, value); }
    public int RenderWidth  { get => _renderWidth;  set => Set(ref _renderWidth, value); }
    public int RenderHeight { get => _renderHeight; set => Set(ref _renderHeight, value); }

    public double DisplayFrequency          { get => _displayFrequency;          set => Set(ref _displayFrequency, value); }
    public double SecondsFromVsyncToPhotons { get => _secondsFromVsyncToPhotons; set => Set(ref _secondsFromVsyncToPhotons, value); }
    public double Ipd                       { get => _ipd;                       set => Set(ref _ipd, value); }
    public bool   IsOnDesktop               { get => _isOnDesktop;               set => Set(ref _isOnDesktop, value); }
}

/// <summary>
/// The whole config, serialised verbatim to
/// %LOCALAPPDATA%\VRSpoofer\config.json, which is what the driver reads.
/// </summary>
public sealed class SpoofConfig : ObservableObject
{
    private bool _enabled = true;
    private bool _verboseLog;
    private double _applyIntervalSeconds = 1.0;
    private string _hmdMode = "off";
    private string _controllerMode = "off";

    public bool   Enabled              { get => _enabled;              set => Set(ref _enabled, value); }
    public bool   VerboseLog           { get => _verboseLog;           set => Set(ref _verboseLog, value); }
    public double ApplyIntervalSeconds { get => _applyIntervalSeconds; set => Set(ref _applyIntervalSeconds, value); }

    /// <summary>"off", "override" or "virtual".</summary>
    public string HmdMode        { get => _hmdMode;        set => Set(ref _hmdMode, value); }
    public string ControllerMode { get => _controllerMode; set => Set(ref _controllerMode, value); }

    public DeviceSpoof Hmd             { get; set; } = new();
    public DeviceSpoof LeftController  { get; set; } = new();
    public DeviceSpoof RightController { get; set; } = new();
    public VirtualDisplay Display      { get; set; } = new();
}
