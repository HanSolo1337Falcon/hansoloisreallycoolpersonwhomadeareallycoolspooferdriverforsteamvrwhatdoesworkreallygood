namespace VRSpoofer.Models;

/// <summary>
/// A one-click identity. Render models and controller_type values here were
/// read out of the SteamVR install, so they resolve to real assets. Icons are
/// referenced by pack name from <see cref="IconCatalogue"/> rather than being
/// embedded, so the icon picker can show and change them independently.
/// </summary>
public sealed class DevicePreset
{
    public required string Name { get; init; }
    public required string Blurb { get; init; }
    public required string Badge { get; init; }
    public required string Glyph { get; init; }
    public required string Accent { get; init; }

    /// <summary>Key into <see cref="IconCatalogue"/>.</summary>
    public string IconPackName { get; init; } = "";

    public string Manufacturer { get; init; } = "";
    public string ModelNumber { get; init; } = "";
    public string TrackingSystem { get; init; } = "";
    public string RenderModel { get; init; } = "";
    public string HardwareRevision { get; init; } = "";
    public string RegisteredDeviceType { get; init; } = "";
    public string ControllerType { get; init; } = "";
    public string InputProfilePath { get; init; } = "";

    public int RenderWidth { get; init; } = 2064;
    public int RenderHeight { get; init; } = 2208;
    public double DisplayFrequency { get; init; } = 90.0;

    /// <summary>Applies the headset fields, resolving the icon pack by name.</summary>
    public void ApplyToHeadset(DeviceSpoof target)
    {
        ApplyCommon(target);
        var pack = IconCatalogue.FindHeadset(IconPackName);
        if (pack is not null)
            target.Icons = pack.Icons.Clone();
        target.RaiseAll();
    }

    /// <summary>Applies the controller fields for one hand.</summary>
    public void ApplyToController(DeviceSpoof target, bool left)
    {
        ApplyCommon(target);
        var pack = IconCatalogue.FindController(IconPackName);
        if (pack is not null)
            target.Icons = (left ? pack.Left : pack.Right).Clone();
        target.RaiseAll();
    }

    private void ApplyCommon(DeviceSpoof target)
    {
        target.Manufacturer = Manufacturer;
        target.ModelNumber = ModelNumber;
        target.TrackingSystem = TrackingSystem;
        target.RenderModel = RenderModel;
        target.HardwareRevision = HardwareRevision;
        target.RegisteredDeviceType = RegisteredDeviceType;
        target.ControllerType = ControllerType;
        target.InputProfilePath = InputProfilePath;
        target.Enabled = true;
    }
}

public static class PresetCatalogue
{
    // ---- headsets ------------------------------------------------------------
    // Every entry points at a different icon pack where the art allows it - two
    // presets that looked identical in the status window were indistinguishable
    // in practice, which is not a preset at all.

    public static readonly IReadOnlyList<DevicePreset> Headsets = new List<DevicePreset>
    {
        new()
        {
            Name = "Valve Index", Blurb = "Valve's lighthouse flagship", Badge = "Lighthouse",
            Glyph = "IX", Accent = "#E85D2A", IconPackName = "Valve Index",
            Manufacturer = "Valve", ModelNumber = "Index", TrackingSystem = "lighthouse",
            RenderModel = "generic_hmd", HardwareRevision = "product 20 rev 2.1.0 lot 2000/0/0 0",
            RenderWidth = 2016, RenderHeight = 2240, DisplayFrequency = 120.0,
        },
        new()
        {
            Name = "Steam Frame", Blurb = "Valve's standalone headset", Badge = "Standalone",
            Glyph = "SF", Accent = "#1A9FFF", IconPackName = "Steam Frame",
            Manufacturer = "Valve", ModelNumber = "Steam Frame", TrackingSystem = "vrlink",
            RenderModel = "generic_hmd",
            RenderWidth = 2160, RenderHeight = 2160, DisplayFrequency = 90.0,
        },
        new()
        {
            Name = "Meta Quest 3", Blurb = "Inside-out, pancake optics", Badge = "Inside-out",
            Glyph = "Q3", Accent = "#1C6BF0", IconPackName = "Meta Quest",
            Manufacturer = "Oculus", ModelNumber = "Meta Quest 3", TrackingSystem = "oculus",
            RenderModel = "generic_hmd",
            RenderWidth = 2064, RenderHeight = 2208, DisplayFrequency = 90.0,
        },
        new()
        {
            Name = "Meta Quest 2", Blurb = "The one everybody has", Badge = "Inside-out",
            Glyph = "Q2", Accent = "#5B6BF0", IconPackName = "Meta Quest",
            Manufacturer = "Oculus", ModelNumber = "Oculus Quest2", TrackingSystem = "oculus",
            RenderModel = "generic_hmd",
            RenderWidth = 1832, RenderHeight = 1920, DisplayFrequency = 90.0,
        },
        new()
        {
            Name = "Meta Quest Pro", Blurb = "Eye and face tracking", Badge = "Inside-out",
            Glyph = "QP", Accent = "#7A5BF0", IconPackName = "Meta Quest",
            Manufacturer = "Oculus", ModelNumber = "Meta Quest Pro", TrackingSystem = "oculus",
            RenderModel = "generic_hmd",
            RenderWidth = 1800, RenderHeight = 1920, DisplayFrequency = 90.0,
        },
        new()
        {
            Name = "Oculus Quest 1", Blurb = "The original standalone", Badge = "Inside-out",
            Glyph = "Q1", Accent = "#4A5BC8", IconPackName = "Oculus Quest 1",
            Manufacturer = "Oculus", ModelNumber = "Oculus Quest", TrackingSystem = "oculus",
            RenderModel = "generic_hmd",
            RenderWidth = 1440, RenderHeight = 1600, DisplayFrequency = 72.0,
        },
        new()
        {
            Name = "Oculus Rift S", Blurb = "Inside-out, 80 Hz LCD", Badge = "Inside-out",
            Glyph = "RS", Accent = "#3D8BF0", IconPackName = "Oculus Rift S",
            Manufacturer = "Oculus", ModelNumber = "Oculus Rift S", TrackingSystem = "oculus",
            RenderModel = "generic_hmd",
            RenderWidth = 1280, RenderHeight = 1440, DisplayFrequency = 80.0,
        },
        new()
        {
            Name = "Oculus Rift CV1", Blurb = "The 2016 original", Badge = "Constellation",
            Glyph = "CV", Accent = "#2F6FD0", IconPackName = "Oculus Rift CV1",
            Manufacturer = "Oculus", ModelNumber = "Oculus Rift CV1", TrackingSystem = "oculus",
            RenderModel = "generic_hmd",
            RenderWidth = 1080, RenderHeight = 1200, DisplayFrequency = 90.0,
        },
        new()
        {
            Name = "Oculus Rift DK2", Blurb = "2014 dev kit", Badge = "Dev kit",
            Glyph = "D2", Accent = "#25507F", IconPackName = "Oculus DK2",
            Manufacturer = "Oculus", ModelNumber = "Oculus Rift DK2", TrackingSystem = "oculus",
            RenderModel = "dk2_hmd",
            RenderWidth = 960, RenderHeight = 1080, DisplayFrequency = 75.0,
        },
        new()
        {
            Name = "Oculus Rift DK1", Blurb = "2013 dev kit", Badge = "Dev kit",
            Glyph = "D1", Accent = "#1E3F66", IconPackName = "Oculus DK1",
            Manufacturer = "Oculus", ModelNumber = "Oculus Rift DK1", TrackingSystem = "oculus",
            RenderModel = "generic_hmd",
            RenderWidth = 640, RenderHeight = 800, DisplayFrequency = 60.0,
        },
        new()
        {
            Name = "HTC Vive", Blurb = "The 2016 lighthouse classic", Badge = "Lighthouse",
            Glyph = "HV", Accent = "#00B2E3", IconPackName = "HTC Vive",
            Manufacturer = "HTC", ModelNumber = "Vive MV", TrackingSystem = "lighthouse",
            RenderModel = "generic_hmd",
            RenderWidth = 1080, RenderHeight = 1200, DisplayFrequency = 90.0,
        },
        new()
        {
            Name = "Vive Pro 2", Blurb = "5K lighthouse headset", Badge = "Lighthouse",
            Glyph = "VP", Accent = "#0090C0", IconPackName = "Vive Pro",
            Manufacturer = "HTC", ModelNumber = "VIVE Pro 2", TrackingSystem = "lighthouse",
            RenderModel = "generic_hmd",
            RenderWidth = 2448, RenderHeight = 2448, DisplayFrequency = 120.0,
        },
        new()
        {
            Name = "Vive Focus Vision", Blurb = "HTC standalone with eye tracking", Badge = "Standalone",
            Glyph = "FV", Accent = "#00A08A", IconPackName = "Vive Focus Vision",
            Manufacturer = "HTC", ModelNumber = "VIVE Focus Vision", TrackingSystem = "vrlink",
            RenderModel = "generic_hmd",
            RenderWidth = 2448, RenderHeight = 2448, DisplayFrequency = 90.0,
        },
        new()
        {
            Name = "Pico 4", Blurb = "Pancake standalone", Badge = "Standalone",
            Glyph = "P4", Accent = "#00C08B", IconPackName = "Pico 4",
            Manufacturer = "Pico", ModelNumber = "Pico 4", TrackingSystem = "vrlink",
            RenderModel = "generic_hmd",
            RenderWidth = 2160, RenderHeight = 2160, DisplayFrequency = 90.0,
        },
        new()
        {
            // Was sharing the Index icons, which made it indistinguishable from
            // the Index preset in the status window.
            Name = "Bigscreen Beyond", Blurb = "Tiny custom-moulded OLED", Badge = "Lighthouse",
            Glyph = "BB", Accent = "#C44BD8", IconPackName = "Lighthouse generic",
            Manufacturer = "Bigscreen", ModelNumber = "Beyond", TrackingSystem = "lighthouse",
            RenderModel = "generic_hmd",
            RenderWidth = 2560, RenderHeight = 2560, DisplayFrequency = 90.0,
        },
        new()
        {
            Name = "Pimax Crystal", Blurb = "Wide FOV, QLED", Badge = "Hybrid",
            Glyph = "PC", Accent = "#E8B32A", IconPackName = "Oculus DK2",
            Manufacturer = "Pimax", ModelNumber = "Pimax Crystal", TrackingSystem = "aapvr",
            RenderModel = "generic_hmd",
            RenderWidth = 2880, RenderHeight = 2880, DisplayFrequency = 90.0,
        },
        new()
        {
            Name = "Varjo Aero", Blurb = "Aspheric, prosumer", Badge = "Lighthouse",
            Glyph = "VA", Accent = "#E8452A", IconPackName = "Oculus DK1",
            Manufacturer = "Varjo", ModelNumber = "Varjo Aero", TrackingSystem = "Varjo",
            RenderModel = "generic_hmd",
            RenderWidth = 2880, RenderHeight = 2720, DisplayFrequency = 90.0,
        },
        new()
        {
            Name = "HP Reverb G2", Blurb = "Windows Mixed Reality", Badge = "WMR",
            Glyph = "G2", Accent = "#0096D6", IconPackName = "Oculus Rift S",
            Manufacturer = "HP", ModelNumber = "Reverb G2", TrackingSystem = "holographic",
            RenderModel = "generic_hmd",
            RenderWidth = 2160, RenderHeight = 2160, DisplayFrequency = 90.0,
        },
    };

    // ---- controllers ---------------------------------------------------------

    public sealed class ControllerPresetPair
    {
        public required string Name { get; init; }
        public required string Blurb { get; init; }
        public required string Badge { get; init; }
        public required string Glyph { get; init; }
        public required string Accent { get; init; }
        public required DevicePreset Left { get; init; }
        public required DevicePreset Right { get; init; }
    }

    // Every controller preset deliberately shares one binding: Quest 2 Touch.
    //
    // controller_type and the input profile are what SteamVR uses to pick a
    // binding file. Varying them per preset is what produces dead buttons and a
    // missing dashboard laser, because the bindings stop matching the input
    // components the real driver actually publishes. So presets change identity
    // and appearance only - name, model, render model, icons - and every one of
    // them reports the same Touch binding.
    //
    // These are constants rather than per-preset arguments so they cannot drift
    // apart again.
    private const string SharedControllerType = "oculus_touch";
    private const string SharedInputProfile = "{oculus}/input/touch_profile.json";

    private static DevicePreset Ctrl(
        string manufacturer, string model, string trackingSystem,
        string renderModel, string iconPack) => new()
    {
        Name = model, Blurb = "", Badge = "", Glyph = "", Accent = "#888888",
        IconPackName = iconPack,
        Manufacturer = manufacturer, ModelNumber = model, TrackingSystem = trackingSystem,
        RenderModel = renderModel,
        ControllerType = SharedControllerType,
        InputProfilePath = SharedInputProfile,
    };

    public static readonly IReadOnlyList<ControllerPresetPair> Controllers = new List<ControllerPresetPair>
    {
        new()
        {
            Name = "Index Controllers", Blurb = "Valve \"Knuckles\", finger tracking",
            Badge = "Lighthouse", Glyph = "KN", Accent = "#E85D2A",
            Left = Ctrl("Valve", "Knuckles Left", "lighthouse",
                        "{indexcontroller}valve_controller_knu_1_0_left", "Index Knuckles"),
            Right = Ctrl("Valve", "Knuckles Right", "lighthouse",
                        "{indexcontroller}valve_controller_knu_1_0_right", "Index Knuckles"),
        },
        new()
        {
            Name = "Vive Wands", Blurb = "The original trackpad wands",
            Badge = "Lighthouse", Glyph = "VW", Accent = "#00B2E3",
            Left = Ctrl("HTC", "VIVE Controller Pro MV", "lighthouse",
                        "vr_controller_vive_1_5", "Vive Wand"),
            Right = Ctrl("HTC", "VIVE Controller Pro MV", "lighthouse",
                        "vr_controller_vive_1_5", "Vive Wand"),
        },
        new()
        {
            Name = "Quest 3 Touch Plus", Blurb = "Ring-less Touch Plus",
            Badge = "Inside-out", Glyph = "T+", Accent = "#1C6BF0",
            Left = Ctrl("Oculus", "Meta Quest 3 (Left Controller)", "oculus",
                        "oculus_quest_plus_controller_left", "Quest Touch"),
            Right = Ctrl("Oculus", "Meta Quest 3 (Right Controller)", "oculus",
                        "oculus_quest_plus_controller_right", "Quest Touch"),
        },
        new()
        {
            Name = "Quest 2 Touch", Blurb = "Ringed Touch controllers",
            Badge = "Inside-out", Glyph = "TQ", Accent = "#5B6BF0",
            Left = Ctrl("Oculus", "Oculus Quest2 (Left Controller)", "oculus",
                        "oculus_quest2_controller_left", "Quest Touch"),
            Right = Ctrl("Oculus", "Oculus Quest2 (Right Controller)", "oculus",
                        "oculus_quest2_controller_right", "Quest Touch"),
        },
        new()
        {
            Name = "Quest Pro Touch", Blurb = "Self-tracked Touch Pro",
            Badge = "Self-tracked", Glyph = "TP", Accent = "#7A5BF0",
            Left = Ctrl("Oculus", "Meta Quest Pro (Left Controller)", "oculus",
                        "oculus_quest_pro_controller_left", "Quest Touch"),
            Right = Ctrl("Oculus", "Meta Quest Pro (Right Controller)", "oculus",
                        "oculus_quest_pro_controller_right", "Quest Touch"),
        },
        new()
        {
            Name = "Quest 1 Touch", Blurb = "Original Quest pair",
            Badge = "Inside-out", Glyph = "T1", Accent = "#4A5BC8",
            Left = Ctrl("Oculus", "Oculus Quest (Left Controller)", "oculus",
                        "oculus_quest_controller_left", "Quest Touch"),
            Right = Ctrl("Oculus", "Oculus Quest (Right Controller)", "oculus",
                        "oculus_quest_controller_right", "Quest Touch"),
        },
        new()
        {
            Name = "Rift S Touch", Blurb = "Rift S generation",
            Badge = "Inside-out", Glyph = "RT", Accent = "#3D8BF0",
            Left = Ctrl("Oculus", "Oculus Rift S (Left Controller)", "oculus",
                        "oculus_rifts_controller_left", "Rift S Touch"),
            Right = Ctrl("Oculus", "Oculus Rift S (Right Controller)", "oculus",
                        "oculus_rifts_controller_right", "Rift S Touch"),
        },
        new()
        {
            Name = "Rift CV1 Touch", Blurb = "The 2016 half-moons",
            Badge = "Constellation", Glyph = "CT", Accent = "#2F6FD0",
            Left = Ctrl("Oculus", "Oculus Rift CV1 (Left Controller)", "oculus",
                        "oculus_cv1_controller_left", "Rift CV1 Touch"),
            Right = Ctrl("Oculus", "Oculus Rift CV1 (Right Controller)", "oculus",
                        "oculus_cv1_controller_right", "Rift CV1 Touch"),
        },
        new()
        {
            Name = "Pico 4 Controllers", Blurb = "Pico's ringed pair",
            Badge = "Standalone", Glyph = "P4", Accent = "#00C08B",
            Left = Ctrl("Pico", "Pico 4 Controller Left", "vrlink",
                        "{vrlink}pico_4_controller_left", "Pico 4"),
            Right = Ctrl("Pico", "Pico 4 Controller Right", "vrlink",
                        "{vrlink}pico_4_controller_right", "Pico 4"),
        },
        new()
        {
            Name = "Pico 4 Ultra", Blurb = "Pico's ring-less pair",
            Badge = "Standalone", Glyph = "PU", Accent = "#00A878",
            Left = Ctrl("Pico", "Pico 4 Ultra Controller Left", "vrlink",
                        "{vrlink}pico_4_ultra_controller_left", "Pico 4 Ultra"),
            Right = Ctrl("Pico", "Pico 4 Ultra Controller Right", "vrlink",
                        "{vrlink}pico_4_ultra_controller_right", "Pico 4 Ultra"),
        },
        new()
        {
            Name = "Vive Focus 3", Blurb = "HTC standalone controllers",
            Badge = "Standalone", Glyph = "F3", Accent = "#00A08A",
            Left = Ctrl("HTC", "VIVE Focus3 Controller Left", "vrlink",
                        "{vrlink}vive_focus3_controller_left", "Vive Focus"),
            Right = Ctrl("HTC", "VIVE Focus3 Controller Right", "vrlink",
                        "{vrlink}vive_focus3_controller_right", "Vive Focus"),
        },
    };
}
