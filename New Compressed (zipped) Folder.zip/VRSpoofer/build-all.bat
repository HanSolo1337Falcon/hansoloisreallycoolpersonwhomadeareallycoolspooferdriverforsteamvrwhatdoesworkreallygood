@echo off
REM Builds the driver, then the GUI with the driver embedded inside it.
REM Output: dist\VRSpoofer.exe (single self-contained file).
REM
REM Order matters - the GUI embeds driver\bin\win64\driver_vrspoofer.dll as a
REM resource, so the driver has to exist first.

setlocal
set "ROOT=%~dp0"

echo.
echo === 1/2  driver ===
call "%ROOT%driver\build.bat"
if errorlevel 1 (
	echo [build-all] driver build failed.
	exit /b 1
)

echo.
echo === 2/2  gui ===
pushd "%ROOT%gui"
dotnet publish -c Release -o "%ROOT%dist"
if errorlevel 1 (
	popd
	echo [build-all] gui build failed.
	exit /b 1
)
popd

echo.
echo === done ===
echo   %ROOT%dist\VRSpoofer.exe
endlocal
exit /b 0
