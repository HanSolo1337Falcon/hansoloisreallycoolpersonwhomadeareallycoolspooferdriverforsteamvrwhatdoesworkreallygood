# VRSpoofer

A SteamVR driver that changes what SteamVR calls your headset and controllers,
plus a control-panel app to drive it. Ships as one self-contained
`VRSpoofer.exe` — the driver is embedded inside it and extracted on install.

```
dist\VRSpoofer.exe
```

## What it actually does

SteamVR builds its status window from device *properties* — `ModelNumber`,
`ManufacturerName`, `RenderModelName`, and the nine `NamedIconPath*` entries.
This driver rewrites those. There are two ways it can do that:

**Override** — the driver publishes no devices of its own. Every frame-ish it
walks the live device list and rewrites the identity properties of the headset
and controllers you already have. This is the mode to use with real hardware:
your ALVR / Link / lighthouse headset keeps working exactly as before, it just
reports a different name. Changes apply within a second, no SteamVR restart.

**Virtual** — the driver publishes its own fake HMD and controllers. Useful
with no hardware attached, or to add controller entries that aren't there.
SteamVR only allows one HMD, so a virtual headset is refused if a real one is
already active (the driver logs this clearly and carries on).

> **Virtual controllers are for when your real ones are off.** A virtual
> controller claims a hand role and sets the controller type, and because it
> activates at driver init — before real hardware wakes up — SteamVR will hand
> it that hand and load *its* bindings, leaving the real controller inert. The
> driver now stands its virtual controllers down automatically as soon as it
> sees a real controller, and switching the mode off releases the hands within
> a second. Use **Override** whenever your controllers are actually on.

Both modes are per-device-class, so you can override the headset while running
virtual controllers, or any other combination.

## Using it

1. Run `VRSpoofer.exe`.
2. **Dashboard → Install driver.** Close SteamVR first if it's running.
   This extracts the driver to `%LOCALAPPDATA%\VRSpoofer\driver` and registers
   it with `vrpathreg`. No administrator rights; nothing is written into
   Program Files or the SteamVR install.
3. **Headset** / **Controllers** — pick a mode, click a preset or type your own
   values.
4. **Apply.** With SteamVR running the change lands within a second.

The **Dashboard** shows a live list of what SteamVR actually reports, read from
the driver inside `vrserver`. That's the ground truth — if a rename worked, it
shows there. **Driver log** is the next place to look if something didn't.

To remove it completely: close SteamVR, then **Uninstall**. That unregisters the
driver and deletes its folder.

## Presets and icons

Presets set a name, render model and icon pack in one click. 18 headsets and
11 controller pairs.

**Every controller preset reports the same binding: Quest 2 Touch**
(`oculus_touch` + `{oculus}/input/touch_profile.json`). Switching between
controller presets changes identity and appearance only — name, model, render
model, icons — and never changes which binding file SteamVR loads. Varying the
binding per preset is what produces dead buttons and a missing dashboard laser,
because the bindings stop matching the input components the real driver
publishes. The two values are constants in `PresetCatalogue` so they cannot
drift apart again.

**Icon packs are separate from presets.** Each page has a *Status icon pack*
picker, so any device name can wear any artwork — call your headset whatever you
like and still show the Rift DK1 icon. There are 13 headset packs and 11
controller packs, covering every status-icon family a stock SteamVR ships:

| Source | Packs |
|---|---|
| `{indexhmd}`, `{lighthouse}` | Valve Index, Lighthouse generic |
| `{htc}` | HTC Vive, Vive Pro, Vive Wand |
| `{oculus}` | Quest, Quest 1, Rift S, Rift CV1, DK2, DK1 and their Touch pairs |
| `{vrlink}` | Steam Frame, Pico 4, Pico 4 Ultra, Vive Focus, hand tracking |
| `{indexcontroller}`, `{gamepad}` | Knuckles, gamepad |

Every path is verified against the real install — a `{driver}` token resolves to
that driver's `resources` directory, and several families are internally
inconsistent (the Vive Focus left hand ships only a `_2x` searching frame; the
right hand's info frame is named `ready_info` while the left's is `info`), so
those are patched explicitly rather than assumed away.

Anything not covered can be typed into the fields directly, and **Advanced**
exposes raw property overrides by numeric `ETrackedDeviceProperty` id via the
config file.

## Notes and limits

- **Serial numbers.** SteamVR binds a serial to a device slot for the whole
  session, so rewriting one on a live device is off by default. The toggle is on
  the Headset page if you want it. Virtual devices always use the serial you set.
- **Turning Virtual mode on needs a SteamVR restart.** Devices can only be
  published while the driver initialises. Renaming *within* a mode is live, and
  turning Virtual mode *off* is also live — the driver stands the virtual
  devices down rather than leaving them holding a hand until you restart.
  A device that has already been published stays in the device list until
  SteamVR restarts, but it will be inert and unassigned.
- **Controller type and input profile are opt-in**, behind *Also rewrite
  controller type and input profile* on the Controllers page. Those two fields
  choose which binding file SteamVR loads. Setting them on real hardware whose
  driver publishes differently-shaped input components gives you dead buttons
  and **no dashboard laser** — the pointer pose comes from the profile. Names,
  icons and render models are safe without it.
- **Render model** changes what the controller looks like in VR, which is
  separate from the name in the status window. A render model that doesn't
  resolve just renders nothing.
- The driver re-checks its work once a second (configurable) because real
  drivers sometimes rewrite their own properties on reconnect.

## Layout

```
driver/                     C++ SteamVR driver
  src/
    dllmain.cpp             HmdDriverFactory export
    ServerDriver.cpp        IServerTrackedDeviceProvider; config polling, status file
    PropertySpoofer.cpp     Override mode - rewrites properties on real devices
    VirtualHmd.cpp          Virtual HMD + IVRDisplayComponent
    VirtualController.cpp   Virtual controllers + input components
    Config.cpp              config.json reader with hot reload
    Logger.cpp              logs to vrserver.txt and driver.log
    MiniJson.h              dependency-free JSON reader
  openvr/openvr_driver.h    from ValveSoftware/openvr
  resources/                driver manifest, settings, input profile
  build.bat

gui/                        .NET 10 WPF control panel
  Models/                   config model, preset catalogue, live status
  Services/                 config I/O, SteamVR discovery, install/uninstall
  ViewModels/MainViewModel.cs
  Theme/Theme.xaml          dark theme, all controls restyled
  MainWindow.xaml

build-all.bat               driver, then gui -> dist\VRSpoofer.exe
```

## Building

Needs the MSVC C++ toolchain and the .NET 10 SDK.

```bat
build-all.bat
```

The driver **must** be built with MSVC. SteamVR loads it into `vrserver.exe`,
which is MSVC-built, and the OpenVR driver API is a set of C++ virtual
interfaces — a MinGW build would not interop.

Files at runtime, all under `%LOCALAPPDATA%\VRSpoofer`:

| File | Written by | Read by |
|---|---|---|
| `config.json` | GUI | driver (polled, hot-reloaded) |
| `status.json` | driver | GUI (live device list) |
| `driver.log` | driver | GUI (log page) |
| `driver/` | GUI on install | SteamVR |
