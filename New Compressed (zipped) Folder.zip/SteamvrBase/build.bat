@echo off
setlocal enabledelayedexpansion
rem Builds driver_SteamvrBase.dll into driver\SteamvrBase\bin\win64\
rem Uses MSVC if available, otherwise falls back to a MinGW-w64 g++ or clang++ on PATH.

set ROOT=%~dp0
set SRC=%ROOT%src\driver_SteamvrBase.cpp
set INC=%ROOT%thirdparty\openvr\headers
set OUTDIR=%ROOT%driver\SteamvrBase\bin\win64
set OUT=%OUTDIR%\driver_SteamvrBase.dll

if not exist "%INC%\openvr_driver.h" (
  echo [!] Missing OpenVR headers at %INC%
  echo     git clone --depth 1 https://github.com/ValveSoftware/openvr thirdparty\openvr
  exit /b 1
)

if not exist "%OUTDIR%" mkdir "%OUTDIR%"

rem ---- Try MSVC -------------------------------------------------------------
set VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe
if exist "%VSWHERE%" (
  for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set VSPATH=%%i
)
if defined VSPATH (
  echo [*] Building with MSVC at !VSPATH!
  call "!VSPATH!\VC\Auxiliary\Build\vcvars64.bat" >nul
  cl /nologo /LD /EHsc /O2 /MT /std:c++17 /I "%INC%" "%SRC%" /Fe:"%OUT%" /Fo:"%OUTDIR%\\" /link /OUT:"%OUT%"
  if errorlevel 1 exit /b 1
  goto :done
)

rem ---- Fall back to g++ / clang++ -------------------------------------------
where g++ >nul 2>&1 && set CXX=g++
if not defined CXX ( where clang++ >nul 2>&1 && set CXX=clang++ )

if not defined CXX (
  echo [!] No C++ compiler found.
  echo     Install one of:
  echo       winget install Microsoft.VisualStudio.2022.BuildTools --override "--quiet --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"
  echo       winget install BrechtSanders.WinLibs.POSIX.UCRT
  exit /b 1
)

echo [*] Building with %CXX%
%CXX% -shared -O2 -std=c++17 -static -static-libgcc -static-libstdc++ -I "%INC%" "%SRC%" -o "%OUT%"
if errorlevel 1 exit /b 1

:done
echo [+] Built %OUT%
endlocal
