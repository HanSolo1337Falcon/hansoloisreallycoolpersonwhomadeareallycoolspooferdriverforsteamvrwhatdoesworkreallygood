// SteamvrBase - a virtual SteamVR driver that publishes N tracking references
// (Lighthouse base stations) so they appear in the SteamVR status window.
//
// The number of base stations (1-63) is read at driver startup from, in order:
//   1. <driver dir>/SteamvrBase.cfg   (a single integer, written by the UI)
//   2. the "SteamvrBase" / "count" key in SteamVR's settings
//   3. the built-in default of 2

#include <openvr_driver.h>

#include <windows.h>

#include <algorithm>
#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

using namespace vr;

static const int kMinCount = 1;

// OpenVR's device array is a fixed k_unMaxTrackedDeviceCount (64) slots, and
// slot 0 is always the HMD, so 63 tracking references is the hard ceiling.
// Anything past that is rejected by TrackedDeviceAdded, and real controllers
// and trackers eat into it further - see the add loop in DeviceProvider::Init.
static const int kMaxCount = (int)k_unMaxTrackedDeviceCount - 1;
static const int kDefaultCount = 2;

static const char *kSettingsSection = "SteamvrBase";

static void Log( const char *fmt, ... )
{
	char buf[512];
	va_list args;
	va_start( args, fmt );
	vsnprintf( buf, sizeof( buf ), fmt, args );
	va_end( args );
	if ( VRDriverLog() )
		VRDriverLog()->Log( buf );
}

// Directory this DLL lives in, used to find SteamvrBase.cfg.
static HMODULE g_hModule = nullptr;

static std::string DriverRootDir()
{
	char path[MAX_PATH] = { 0 };
	if ( !GetModuleFileNameA( g_hModule, path, MAX_PATH ) )
		return std::string();

	// .../SteamvrBase/bin/win64/driver_SteamvrBase.dll -> .../SteamvrBase
	std::string s( path );
	for ( int i = 0; i < 3; ++i )
	{
		size_t slash = s.find_last_of( "\\/" );
		if ( slash == std::string::npos )
			return std::string();
		s.erase( slash );
	}
	return s;
}

static bool ReadCountFromFile( int *outCount )
{
	std::string root = DriverRootDir();
	if ( root.empty() )
		return false;

	std::string cfg = root + "\\SteamvrBase.cfg";
	FILE *f = fopen( cfg.c_str(), "r" );
	if ( !f )
		return false;

	int value = 0;
	bool ok = ( fscanf( f, "%d", &value ) == 1 );
	fclose( f );

	if ( ok )
		*outCount = value;
	return ok;
}

static int ResolveCount()
{
	int count = kDefaultCount;

	if ( !ReadCountFromFile( &count ) )
	{
		EVRSettingsError err = VRSettingsError_None;
		int fromSettings = VRSettings()->GetInt32( kSettingsSection, "count", &err );
		if ( err == VRSettingsError_None )
			count = fromSettings;
	}

	return std::min( kMaxCount, std::max( kMinCount, count ) );
}

static HmdQuaternion_t QuatFromYaw( double yawRadians )
{
	HmdQuaternion_t q;
	q.w = std::cos( yawRadians * 0.5 );
	q.x = 0.0;
	q.y = std::sin( yawRadians * 0.5 );
	q.z = 0.0;
	return q;
}

static HmdQuaternion_t QuatMul( const HmdQuaternion_t &a, const HmdQuaternion_t &b )
{
	HmdQuaternion_t q;
	q.w = a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z;
	q.x = a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y;
	q.y = a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x;
	q.z = a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w;
	return q;
}

// Orientation that points the device's -Z axis (the way a base station looks)
// from `from` at `to`: yaw about world Y, then pitch about the device's own X.
static HmdQuaternion_t QuatLookAt( const double from[3], const double to[3] )
{
	const double dx = to[0] - from[0];
	const double dy = to[1] - from[1];
	const double dz = to[2] - from[2];

	const double len = std::sqrt( dx * dx + dy * dy + dz * dz );
	if ( len < 1e-6 )
		return QuatFromYaw( 0.0 );

	const double yaw = std::atan2( -dx, -dz );
	const double pitch = std::asin( std::max( -1.0, std::min( 1.0, dy / len ) ) );

	HmdQuaternion_t qPitch;
	qPitch.w = std::cos( pitch * 0.5 );
	qPitch.x = std::sin( pitch * 0.5 );
	qPitch.y = 0.0;
	qPitch.z = 0.0;

	return QuatMul( QuatFromYaw( yaw ), qPitch );
}

//-----------------------------------------------------------------------------
// One virtual base station.
//-----------------------------------------------------------------------------
class BaseStation : public ITrackedDeviceServerDriver
{
public:
	BaseStation( int index, int total )
		: m_index( index )
		, m_total( total )
		, m_objectId( k_unTrackedDeviceIndexInvalid )
	{
		char serial[64];
		snprintf( serial, sizeof( serial ), "LHB-SVB%05d", index + 1 );
		m_serial = serial;

		// Small counts sit on a single 4 m ring at 2.5 m, like a real room-scale
		// setup. Larger counts stack into concentric rings at rising heights, so
		// dozens of stations stay visually distinct instead of clipping into one
		// another around a single circle.
		const double kPi = 3.14159265358979323846;
		const int perRing = 12;
		const int ring = ( total <= perRing ) ? 0 : ( index / perRing );
		const int inRing = ( total <= perRing ) ? index : ( index % perRing );
		const int ringTotal = ( total <= perRing )
			? total
			: std::min( perRing, total - ring * perRing );

		const double angle = ( 2.0 * kPi * inRing ) / ( ringTotal > 0 ? ringTotal : 1 );
		const double radius = 4.0 + ring * 1.5;

		m_x = radius * std::sin( angle );
		m_y = 2.5 + ring * 0.8;
		m_z = -radius * std::cos( angle );

		// Until an HMD pose shows up, aim at the middle of the playspace at
		// roughly head height.
		m_targetX = 0.0;
		m_targetY = 1.7;
		m_targetZ = 0.0;
	}

	// Point this station at a world-space location (the headset).
	void AimAt( double x, double y, double z )
	{
		m_targetX = x;
		m_targetY = y;
		m_targetZ = z;
	}

	const std::string &Serial() const { return m_serial; }

	EVRInitError Activate( uint32_t unObjectId ) override
	{
		m_objectId = unObjectId;
		if ( !VRProperties() )
			return VRInitError_Driver_Failed;

		PropertyContainerHandle_t container =
			VRProperties()->TrackedDeviceToPropertyContainer( m_objectId );

		VRProperties()->SetStringProperty( container, Prop_SerialNumber_String, m_serial.c_str() );
		VRProperties()->SetStringProperty( container, Prop_ModelNumber_String, "ValveBaseStation2.0" );
		VRProperties()->SetStringProperty( container, Prop_RenderModelName_String, "lh_basestation_vive" );
		VRProperties()->SetStringProperty( container, Prop_ManufacturerName_String, "SteamvrBase" );
		VRProperties()->SetStringProperty( container, Prop_TrackingSystemName_String, "SteamvrBase" );
		VRProperties()->SetStringProperty( container, Prop_HardwareRevision_String, "2.0" );

		// SteamVR shows this next to the base station icon.
		char label[8];
		snprintf( label, sizeof( label ), "%d", m_index + 1 );
		VRProperties()->SetStringProperty( container, Prop_ModeLabel_String, label );

		VRProperties()->SetInt32Property( container, Prop_DeviceClass_Int32,
			TrackedDeviceClass_TrackingReference );

		VRProperties()->SetFloatProperty( container, Prop_FieldOfViewLeftDegrees_Float, 60.0f );
		VRProperties()->SetFloatProperty( container, Prop_FieldOfViewRightDegrees_Float, 60.0f );
		VRProperties()->SetFloatProperty( container, Prop_FieldOfViewTopDegrees_Float, 60.0f );
		VRProperties()->SetFloatProperty( container, Prop_FieldOfViewBottomDegrees_Float, 60.0f );
		VRProperties()->SetFloatProperty( container, Prop_TrackingRangeMinimumMeters_Float, 0.5f );
		VRProperties()->SetFloatProperty( container, Prop_TrackingRangeMaximumMeters_Float, 10.0f );

		// Status-window icons. Without these SteamVR falls back to the generic
		// hexagon. {lighthouse} is the stock Valve driver, always present, and
		// already ships the 2.0 base station artwork.
		VRProperties()->SetStringProperty( container, Prop_NamedIconPathDeviceOff_String,
			"{lighthouse}/icons/base2_status_off.png" );
		VRProperties()->SetStringProperty( container, Prop_NamedIconPathDeviceSearching_String,
			"{lighthouse}/icons/base2_status_searching.gif" );
		VRProperties()->SetStringProperty( container, Prop_NamedIconPathDeviceSearchingAlert_String,
			"{lighthouse}/icons/base2_status_searching_alert.gif" );
		VRProperties()->SetStringProperty( container, Prop_NamedIconPathDeviceReady_String,
			"{lighthouse}/icons/base2_status_ready.png" );
		VRProperties()->SetStringProperty( container, Prop_NamedIconPathDeviceReadyAlert_String,
			"{lighthouse}/icons/base2_status_ready_alert.png" );
		VRProperties()->SetStringProperty( container, Prop_NamedIconPathDeviceNotReady_String,
			"{lighthouse}/icons/base2_status_error.png" );
		VRProperties()->SetStringProperty( container, Prop_NamedIconPathDeviceStandby_String,
			"{lighthouse}/icons/base2_status_standby.png" );
		VRProperties()->SetStringProperty( container, Prop_NamedIconPathDeviceStandbyAlert_String,
			"{lighthouse}/icons/base2_status_standby.png" );
		VRProperties()->SetStringProperty( container, Prop_NamedIconPathDeviceAlertLow_String,
			"{lighthouse}/icons/base2_status_error.png" );
		VRProperties()->SetStringProperty( container,
			Prop_NamedIconPathTrackingReferenceDeviceOff_String,
			"{lighthouse}/icons/base2_status_off.png" );

		VRProperties()->SetBoolProperty( container, Prop_NeverTracked_Bool, false );
		VRProperties()->SetBoolProperty( container, Prop_CanWirelessIdentify_Bool, false );
		VRProperties()->SetBoolProperty( container, Prop_DeviceProvidesBatteryStatus_Bool, false );

		Log( "activated %s", m_serial.c_str() );
		return VRInitError_None;
	}

	void Deactivate() override { m_objectId = k_unTrackedDeviceIndexInvalid; }
	void EnterStandby() override {}
	void *GetComponent( const char * ) override { return nullptr; }

	void DebugRequest( const char *, char *pchResponseBuffer, uint32_t unResponseBufferSize ) override
	{
		if ( unResponseBufferSize > 0 )
			pchResponseBuffer[0] = '\0';
	}

	DriverPose_t GetPose() override
	{
		DriverPose_t pose = { 0 };
		pose.poseIsValid = true;
		pose.result = TrackingResult_Running_OK;
		pose.deviceIsConnected = true;

		pose.qWorldFromDriverRotation = QuatFromYaw( 0.0 );
		pose.qDriverFromHeadRotation = QuatFromYaw( 0.0 );

		pose.vecPosition[0] = m_x;
		pose.vecPosition[1] = m_y;
		pose.vecPosition[2] = m_z;

		const double from[3] = { m_x, m_y, m_z };
		const double to[3] = { m_targetX, m_targetY, m_targetZ };
		pose.qRotation = QuatLookAt( from, to );
		return pose;
	}

	void Update()
	{
		// The context is torn down before the last calls stop arriving, so
		// never assume the host is still there.
		if ( m_objectId == k_unTrackedDeviceIndexInvalid || !VRServerDriverHost() )
			return;
		VRServerDriverHost()->TrackedDevicePoseUpdated( m_objectId, GetPose(), sizeof( DriverPose_t ) );
	}

private:
	int m_index;
	int m_total;
	uint32_t m_objectId;
	std::string m_serial;
	double m_x, m_y, m_z;
	double m_targetX, m_targetY, m_targetZ;
};

//-----------------------------------------------------------------------------
// Driver provider.
//-----------------------------------------------------------------------------
class DeviceProvider : public IServerTrackedDeviceProvider
{
public:
	EVRInitError Init( IVRDriverContext *pDriverContext ) override
	{
		VR_INIT_SERVER_DRIVER_CONTEXT( pDriverContext );

		const int count = ResolveCount();
		Log( "creating %d base station(s)", count );

		for ( int i = 0; i < count; ++i )
		{
			BaseStation *station = new BaseStation( i, count );

			// SteamVR refuses this once its 64 device slots are full - which
			// happens sooner than kMaxCount when real controllers and trackers
			// are connected. Stop cleanly rather than leaking rejected devices.
			if ( !VRServerDriverHost()->TrackedDeviceAdded(
					station->Serial().c_str(), TrackedDeviceClass_TrackingReference, station ) )
			{
				delete station;
				Log( "SteamVR refused device %d of %d - all %u tracked "
					"device slots are in use. Added %d base station(s).",
					i + 1, count, k_unMaxTrackedDeviceCount, (int)m_stations.size() );
				break;
			}

			m_stations.push_back( station );
		}

		return VRInitError_None;
	}

	void Cleanup() override
	{
		// Deliberately do NOT delete the stations. SteamVR keeps the
		// ITrackedDeviceServerDriver pointers handed to TrackedDeviceAdded and
		// can still call into them (Deactivate, GetPose, EnterStandby) during
		// and after teardown - freeing them here is a use-after-free that shows
		// up as an access violation in vrserver at standby/shutdown. They are
		// released when the process exits.
		m_stations.clear();
		VR_CLEANUP_SERVER_DRIVER_CONTEXT();
	}

	const char *const *GetInterfaceVersions() override { return k_InterfaceVersions; }

	void RunFrame() override
	{
		if ( !VRServerDriverHost() )
			return;

		// Aim every station at the headset, so the models always face the user.
		TrackedDevicePose_t poses[k_unMaxTrackedDeviceCount] = { };
		VRServerDriverHost()->GetRawTrackedDevicePoses( 0.0f, poses, k_unMaxTrackedDeviceCount );

		const TrackedDevicePose_t &hmd = poses[k_unTrackedDeviceIndex_Hmd];
		if ( hmd.bPoseIsValid && hmd.bDeviceIsConnected )
		{
			const HmdMatrix34_t &m = hmd.mDeviceToAbsoluteTracking;
			for ( size_t i = 0; i < m_stations.size(); ++i )
				m_stations[i]->AimAt( m.m[0][3], m.m[1][3], m.m[2][3] );
		}

		for ( size_t i = 0; i < m_stations.size(); ++i )
			m_stations[i]->Update();
	}

	bool ShouldBlockStandbyMode() override { return false; }
	void EnterStandby() override {}
	void LeaveStandby() override {}

private:
	std::vector<BaseStation *> m_stations;
};

static DeviceProvider g_deviceProvider;

BOOL APIENTRY DllMain( HMODULE hModule, DWORD reason, LPVOID )
{
	if ( reason == DLL_PROCESS_ATTACH )
		g_hModule = hModule;
	return TRUE;
}

extern "C" __declspec( dllexport ) void *HmdDriverFactory( const char *pInterfaceName, int *pReturnCode )
{
	if ( strcmp( IServerTrackedDeviceProvider_Version, pInterfaceName ) == 0 )
		return &g_deviceProvider;

	if ( pReturnCode )
		*pReturnCode = VRInitError_Init_InterfaceNotFound;
	return nullptr;
}
