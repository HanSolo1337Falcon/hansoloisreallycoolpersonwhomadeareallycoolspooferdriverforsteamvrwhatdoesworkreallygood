"""SteamvrBase - installer / configurator UI.

Installs the SteamvrBase SteamVR driver and sets how many virtual base
stations (1-63) show up in the SteamVR status window.
"""

import json
import os
import shutil
import subprocess
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

MIN_COUNT = 1
# OpenVR's device array is a fixed 64 slots and slot 0 is the HMD, so 63 is the
# hard ceiling. Connected controllers and trackers eat into it further, and the
# driver stops cleanly when SteamVR runs out of slots.
MAX_COUNT = 63
DRIVER_NAME = "SteamvrBase"


# ---------------------------------------------------------------- payload ---
def payload_dir():
    """Folder holding the driver files to install (bundled or on disk)."""
    base = getattr(sys, "_MEIPASS", None)
    if base:
        return os.path.join(base, "driver", DRIVER_NAME)
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.abspath(os.path.join(here, "..", "driver", DRIVER_NAME))


# ------------------------------------------------------------- steamvr fs ---
def steam_paths_from_registry():
    paths = []
    try:
        import winreg
    except ImportError:
        return paths
    for root, key, value in (
        (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamPath"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath"),
    ):
        try:
            with winreg.OpenKey(root, key) as k:
                paths.append(os.path.normpath(winreg.QueryValueEx(k, value)[0]))
        except OSError:
            pass
    return paths


def steam_libraries():
    """Every Steam library folder we can find."""
    libs = []
    for steam in steam_paths_from_registry() + [
        r"C:\Program Files (x86)\Steam",
        r"C:\Program Files\Steam",
    ]:
        if steam and steam not in libs and os.path.isdir(steam):
            libs.append(steam)

    # libraryfolders.vdf lists libraries on other drives.
    for steam in list(libs):
        vdf = os.path.join(steam, "steamapps", "libraryfolders.vdf")
        if not os.path.isfile(vdf):
            continue
        try:
            with open(vdf, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    parts = line.split('"')
                    if len(parts) >= 5 and parts[1] == "path":
                        p = os.path.normpath(parts[3].replace("\\\\", "\\"))
                        if os.path.isdir(p) and p not in libs:
                            libs.append(p)
        except OSError:
            pass
    return libs


def find_steamvr():
    for lib in steam_libraries():
        p = os.path.join(lib, "steamapps", "common", "SteamVR")
        if os.path.isdir(os.path.join(p, "drivers")):
            return p
    return None


def steamvr_running():
    try:
        out = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq vrserver.exe"],
            capture_output=True, text=True, timeout=10,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        ).stdout.lower()
        return "vrserver.exe" in out
    except Exception:
        return False


# ------------------------------------------------------------ install ops ---
def installed_dir(steamvr):
    return os.path.join(steamvr, "drivers", DRIVER_NAME)


def write_count(target, count):
    """Write the count everywhere the driver looks for it."""
    with open(os.path.join(target, "SteamvrBase.cfg"), "w", encoding="utf-8") as f:
        f.write(str(count))

    settings = os.path.join(target, "resources", "settings", "default.vrsettings")
    os.makedirs(os.path.dirname(settings), exist_ok=True)
    with open(settings, "w", encoding="utf-8") as f:
        json.dump({DRIVER_NAME: {"count": count}}, f, indent=3)


def clear_user_override(steamvr):
    """Drop a stale SteamvrBase count in the user's steamvr.vrsettings.

    A user-level value there would shadow our default.vrsettings.
    """
    cfg = os.path.abspath(os.path.join(steamvr, "..", "..", "..", "config", "steamvr.vrsettings"))
    if not os.path.isfile(cfg):
        return
    try:
        with open(cfg, "r", encoding="utf-8", errors="replace") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return
    if DRIVER_NAME in data:
        data.pop(DRIVER_NAME)
        try:
            with open(cfg, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=3)
        except OSError:
            pass


def _clear_readonly(func, path, _exc):
    """rmtree handler: strip the read-only attribute and retry once.

    Files copied out of a read-only source (or a synced folder) keep that
    attribute, and Windows refuses to delete them until it is cleared.
    """
    import stat
    try:
        os.chmod(path, stat.S_IWRITE)
        func(path)
    except OSError:
        raise


def _rmtree(path):
    """Remove a tree, clearing read-only flags and retrying if a file is locked."""
    import time
    kw = {"onexc": _clear_readonly} if sys.version_info >= (3, 12) else {
        "onerror": lambda f, p, e: _clear_readonly(f, p, e)}
    last = None
    for attempt in range(8):
        try:
            shutil.rmtree(path, **kw)
            return
        except OSError as exc:
            last = exc
            time.sleep(0.25 * (attempt + 1))
    raise RuntimeError(
        "Could not remove:\n%s\n\nA file is locked (%s).\n\n"
        "Close SteamVR completely, then try again." % (path, last)
    )


def install(steamvr, count):
    src = payload_dir()
    dll = os.path.join(src, "bin", "win64", "driver_%s.dll" % DRIVER_NAME)
    if not os.path.isfile(dll):
        raise RuntimeError(
            "driver_%s.dll is missing.\n\nExpected at:\n%s\n\n"
            "Run build.bat to compile the driver first." % (DRIVER_NAME, dll)
        )

    # Overwrite in place rather than delete-then-copy: Windows frequently holds
    # a lock on the freshly written DLL's folder, which makes rmtree fail here.
    target = installed_dir(steamvr)
    shutil.copytree(src, target, dirs_exist_ok=True)
    write_count(target, count)
    clear_user_override(steamvr)
    return target


def uninstall(steamvr):
    target = installed_dir(steamvr)
    if os.path.isdir(target):
        _rmtree(target)
        return True
    return False


def current_count(steamvr):
    cfg = os.path.join(installed_dir(steamvr), "SteamvrBase.cfg")
    try:
        with open(cfg, "r", encoding="utf-8") as f:
            return max(MIN_COUNT, min(MAX_COUNT, int(f.read().strip())))
    except (OSError, ValueError):
        return None


# --------------------------------------------------------------------- ui ---
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("SteamvrBase")
        self.resizable(False, False)
        self.configure(padx=18, pady=14)

        self.steamvr = find_steamvr()
        self.count = tk.IntVar(value=2)

        ttk.Label(self, text="SteamvrBase", font=("Segoe UI", 15, "bold")).grid(
            row=0, column=0, columnspan=3, sticky="w")
        ttk.Label(self, text="Virtual Lighthouse base stations for the SteamVR status window.",
                  foreground="#666").grid(row=1, column=0, columnspan=3, sticky="w")
        ttk.Label(self, text="Max is 63: SteamVR has 64 device slots total and the headset takes one. "
                             "Controllers and trackers use up more.",
                  foreground="#888", wraplength=430, justify="left").grid(
            row=2, column=0, columnspan=3, sticky="w", pady=(2, 12))

        ttk.Label(self, text="Base stations:").grid(row=3, column=0, sticky="w")
        self.scale = ttk.Scale(self, from_=MIN_COUNT, to=MAX_COUNT, orient="horizontal",
                               length=260, command=self._on_scale)
        self.scale.grid(row=3, column=1, sticky="we", padx=8)
        self.spin = ttk.Spinbox(self, from_=MIN_COUNT, to=MAX_COUNT, width=5,
                                textvariable=self.count, command=self._on_spin)
        self.spin.grid(row=3, column=2, sticky="e")
        self.spin.bind("<KeyRelease>", lambda _e: self._on_spin())
        self.scale.set(2)

        ttk.Separator(self).grid(row=4, column=0, columnspan=3, sticky="we", pady=12)

        path_row = ttk.Frame(self)
        path_row.grid(row=5, column=0, columnspan=3, sticky="we")
        ttk.Label(path_row, text="SteamVR:").pack(side="left")
        self.path_var = tk.StringVar(value=self.steamvr or "not found")
        ttk.Entry(path_row, textvariable=self.path_var, width=48, state="readonly").pack(
            side="left", padx=6)
        ttk.Button(path_row, text="Browse...", command=self.browse).pack(side="left")

        btns = ttk.Frame(self)
        btns.grid(row=6, column=0, columnspan=3, sticky="we", pady=(14, 6))
        ttk.Button(btns, text="Install / Apply", command=self.do_install).pack(side="left")
        ttk.Button(btns, text="Uninstall", command=self.do_uninstall).pack(side="left", padx=8)
        ttk.Button(btns, text="Quit", command=self.destroy).pack(side="right")

        self.status = tk.StringVar()
        ttk.Label(self, textvariable=self.status, foreground="#0a6", wraplength=430,
                  justify="left").grid(row=7, column=0, columnspan=3, sticky="w")

        self.refresh()

    # -- count widgets stay in sync
    def _on_scale(self, value):
        self.count.set(int(round(float(value))))

    def _on_spin(self):
        try:
            v = int(self.spin.get())
        except ValueError:
            return
        v = max(MIN_COUNT, min(MAX_COUNT, v))
        self.count.set(v)
        self.scale.set(v)

    def browse(self):
        d = filedialog.askdirectory(title="Select your SteamVR folder")
        if not d:
            return
        if not os.path.isdir(os.path.join(d, "drivers")):
            messagebox.showerror("SteamvrBase", "That folder has no 'drivers' subfolder.")
            return
        self.steamvr = os.path.normpath(d)
        self.path_var.set(self.steamvr)
        self.refresh()

    def refresh(self):
        if not self.steamvr:
            self.status.set("SteamVR not found - use Browse to point at it.")
            return
        existing = current_count(self.steamvr)
        if existing is None:
            self.status.set("Not installed yet. Pick a number and hit Install / Apply.")
        else:
            self.count.set(existing)
            self.scale.set(existing)
            self.status.set("Installed, currently showing %d base station(s)." % existing)

    def do_install(self):
        if not self.steamvr:
            messagebox.showerror("SteamvrBase", "Point at your SteamVR folder first.")
            return
        n = self.count.get()
        if steamvr_running() and not messagebox.askyesno(
                "SteamvrBase",
                "SteamVR is running. Changes only take effect after a restart.\n\nInstall anyway?"):
            return
        try:
            install(self.steamvr, n)
        except Exception as exc:
            messagebox.showerror("SteamvrBase", str(exc))
            return
        self.status.set("Installed %d base station(s). Restart SteamVR to see them." % n)

    def do_uninstall(self):
        if not self.steamvr:
            return
        if not messagebox.askyesno("SteamvrBase", "Remove the SteamvrBase driver?"):
            return
        try:
            removed = uninstall(self.steamvr)
        except Exception as exc:
            messagebox.showerror("SteamvrBase", str(exc))
            return
        self.status.set("Driver removed. Restart SteamVR." if removed else "Driver was not installed.")


if __name__ == "__main__":
    App().mainloop()
