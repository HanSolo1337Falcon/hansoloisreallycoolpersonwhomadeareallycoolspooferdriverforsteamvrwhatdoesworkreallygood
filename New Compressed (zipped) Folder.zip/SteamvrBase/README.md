# SteamvrBase

A virtual SteamVR driver that publishes 1–63 Lighthouse base stations so they
show up in the SteamVR status window, plus a GUI installer for picking the count.

## Use it

Run `dist\SteamvrBase.exe`:

1. It auto-detects your SteamVR install (Browse… if it guesses wrong).
2. Drag the slider or type a number, 1–63.
3. **Install / Apply** copies the driver in and writes the count.
4. **Restart SteamVR.** The stations appear in the status window.

**Uninstall** removes the driver folder. SteamVR must be closed — while it's
running the DLL is loaded and Windows won't let it be deleted.

## Layout

| Path | What |
| --- | --- |
| `src/driver_SteamvrBase.cpp` | The driver |
| `driver/SteamvrBase/` | Installable driver folder (manifest, settings, built DLL) |
| `ui/SteamvrBaseConfig.py` | The GUI |
| `dist/SteamvrBase.exe` | Built GUI, with the driver bundled inside |
| `build.bat` | Rebuilds the DLL |

## How the count is read

The driver resolves it at startup, first match wins:

1. `SteamvrBase.cfg` in the driver folder — a bare integer, what the GUI writes
2. the `SteamvrBase` / `count` key in SteamVR's settings
3. the built-in default of 2

Values are clamped to 1–63. Up to 12 stations sit on a single 4 m ring at 2.5 m,
like a real room-scale setup; past that they stack into concentric rings at
rising radius and height so they stay visually distinct. Serials run
`LHB-SVB00001`…

### Why 63 and not more

OpenVR's tracked-device array is a fixed `k_unMaxTrackedDeviceCount = 64` slots,
and slot 0 is always the HMD — so 63 tracking references is the hard ceiling
imposed by SteamVR itself, not by this driver. Connected controllers and
trackers consume slots too, so the practical number is lower. The driver checks
`TrackedDeviceAdded`'s return value, stops cleanly when SteamVR runs out of
slots, and logs how many it managed to add.

Every frame the driver reads the headset pose and re-aims all of the models at
it — yaw and pitch — so they follow you as you move around. Before an HMD pose
is available they point at the middle of the playspace at head height.

## Rebuilding

```
build.bat
```

Uses MSVC if it's installed, otherwise a MinGW-w64 `g++` or `clang++` on PATH.
The shipped DLL was built with MinGW-w64 (WinLibs UCRT), statically linked — it
depends only on `kernel32` and the system UCRT.

Headers come from `thirdparty/openvr` (`git clone --depth 1
https://github.com/ValveSoftware/openvr thirdparty/openvr`).

To rebuild the exe after changing the GUI:

```
python -m PyInstaller --noconfirm --onefile --windowed --name SteamvrBase --add-data "driver;driver" ui/SteamvrBaseConfig.py
```

## Note

You already have a `driver_fake_basestations` driver installed in SteamVR. It
does the same job, so if both are active you'll see both sets of stations.
Remove or disable one.
