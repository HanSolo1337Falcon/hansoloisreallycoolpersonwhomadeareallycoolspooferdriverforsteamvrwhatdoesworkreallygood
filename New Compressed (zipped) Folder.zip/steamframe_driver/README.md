# steamframe driver

A SteamVR driver that makes SteamVR show a Steam Frame setup in the status window:

- **Headset**: Steam Frame icon (from SteamVR's `vrlink` driver)
- **Left and right controllers**: Steam Frame controller icons, 3D models and input profile (from SteamVR's `frame_controller` driver)
- **Connection**: an extra status icon for how the headset is connected: USB, wireless dongle, or via a router

Nothing is tracked. The devices sit still. The headset acts as a virtual display: SteamVR renders to it and the frames are thrown away.

## Layout

```
steamframe/                      <- the driver folder SteamVR loads
  driver.vrdrivermanifest
  bin/win64/driver_steamframe.dll
  resources/settings/default.vrsettings
src/                             <- C++ source
third_party/openvr/openvr_driver.h
install.ps1 / uninstall.ps1
```

## Build

You need Visual Studio 2022 (or the Build Tools) and CMake. Keep the build folder on a short path, because MSBuild breaks on paths over 260 characters:

```powershell
cmake -S . -B C:\sfb -G "Visual Studio 17 2022" -A x64
cmake --build C:\sfb --config Release
```

The DLL goes straight into `steamframe/bin/win64/`.

## Install

Close SteamVR, then run:

```powershell
powershell -ExecutionPolicy Bypass -File install.ps1
```

This copies `steamframe/` to `SteamVR\drivers\steamframe`. If a real headset is connected, SteamVR may pick that one instead. To force this driver, add `"forcedDriver": "steamframe"` under `"steamvr"` in `Steam\config\steamvr.vrsettings`.

To remove it, run `uninstall.ps1`.

## Settings (`driver_steamframe` in `default.vrsettings`)

| key | default | meaning |
|---|---|---|
| `connectionType` | `usb` | `usb`, `dongle`, `wired_to_router`, `wireless_to_router`. Picks the connection icon |
| `showConnection` | `true` | show the connection icon |
| `enableControllers` | `true` | add the two controllers |
| `hmdBatteryPercent` / `leftBatteryPercent` / `rightBatteryPercent` | `100` | battery level shown on the icons (a low value shows the low-battery icon) |
| `charging` | `false` | report the devices as charging |
| `hmdModelNumber`, `controllerModelNumber`, `manufacturer`, `*SerialNumber` | | names shown in SteamVR |
| `virtualDisplay` | `true` | act as a virtual (wireless-style) display, so no window appears on the desktop. If `false`, the headset is a desktop window instead, and SteamVR shows "Headset Error (-202)" (display not fullscreen) |
| `windowX/Y/Width/Height` | 0,0,1920,1080 | where the window goes when `virtualDisplay` is `false` |
| `renderWidth/Height` | 2160 | per-eye render size |
| `displayFrequency` | 90 | refresh rate in Hz |

You can also override any of these in `Steam\config\steamvr.vrsettings` under a `"driver_steamframe"` section, so you don't need to edit the driver folder.

## About the connection icon

SteamVR's own link indicator (the one Steam Link / a real Frame shows next to the headset) gets its data from a private SteamVR interface that only Valve's `vrlink` driver can reach. This driver can't light that one up. Instead, it adds a separate status device that uses the same icons (`{vrlink}/icons/link_usb.png`, `link_dongle.png`, …).

The icons are loaded from SteamVR's installed `vrlink` and `frame_controller` drivers, so they will break if Valve renames or moves those files.
