"""SteamFrame Driver manager.

Installs/uninstalls the steamframe SteamVR driver and edits its settings.
Double-click to run (no console window). Keep this file next to the
"steamframe" driver folder.
"""

import json
import os
import shutil
import subprocess
import tkinter as tk
import winreg
from pathlib import Path
from tkinter import messagebox, ttk

HERE = Path(os.path.abspath(__file__)).parent
SRC_DRIVER = HERE / "steamframe"
DRIVER = "steamframe"
SECTION = "driver_steamframe"
SETTINGS_REL = Path("resources") / "settings" / "default.vrsettings"
CONNECTIONS = [
    ("USB", "usb"),
    ("Wireless dongle", "dongle"),
    ("Wired to router", "wired_to_router"),
    ("Wireless to router", "wireless_to_router"),
]
FREQUENCIES = ["72", "80", "90", "120", "144"]
NO_WINDOW = 0x08000000  # CREATE_NO_WINDOW, so tasklist doesn't flash a console


def lp(path):
    """Long-path form, so copies work even past Windows' 260-character limit."""
    s = os.path.abspath(str(path))
    return s if s.startswith("\\\\?\\") else "\\\\?\\" + s


def steam_dir():
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as key:
            return Path(winreg.QueryValueEx(key, "SteamPath")[0])
    except OSError:
        return Path(r"C:\Program Files (x86)\Steam")


def steamvr_dir():
    # openvrpaths.vrpath knows where the active SteamVR runtime lives.
    vrpath = Path(os.environ.get("LOCALAPPDATA", "")) / "openvr" / "openvrpaths.vrpath"
    try:
        for runtime in json.loads(vrpath.read_text(encoding="utf-8")).get("runtime", []):
            if (Path(runtime) / "bin").is_dir():
                return Path(runtime)
    except (OSError, ValueError):
        pass
    return steam_dir() / "steamapps" / "common" / "SteamVR"


def steamvr_running():
    try:
        out = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq vrserver.exe", "/NH"],
            capture_output=True, text=True, creationflags=NO_WINDOW,
        ).stdout
        return "vrserver.exe" in out.lower()
    except OSError:
        return False


def read_json(path):
    with open(lp(path), encoding="utf-8-sig") as f:
        return json.load(f)


def write_json(path, data, indent="\t"):
    with open(lp(path), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=indent)
        f.write("\n")


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("SteamFrame Driver")
        self.resizable(False, False)

        self.steamvr = steamvr_dir()
        self.installed_dir = self.steamvr / "drivers" / DRIVER
        self.vrsettings = steam_dir() / "config" / "steamvr.vrsettings"

        self.connection = tk.StringVar()
        self.show_connection = tk.BooleanVar()
        self.enable_controllers = tk.BooleanVar()
        self.charging = tk.BooleanVar()
        self.battery = {k: tk.IntVar() for k in ("hmdBatteryPercent", "leftBatteryPercent", "rightBatteryPercent")}
        self.frequency = tk.StringVar()
        self.hmd_model = tk.StringVar()
        self.controller_model = tk.StringVar()
        self.forced = tk.BooleanVar()
        self.status = tk.StringVar()

        self._build()
        self.load_settings()
        self.refresh_status()

    # ---- layout ----------------------------------------------------------

    def _build(self):
        pad = {"padx": 10, "pady": 4}
        root = ttk.Frame(self, padding=10)
        root.grid()

        status = ttk.LabelFrame(root, text="Driver", padding=8)
        status.grid(row=0, column=0, sticky="ew", **pad)
        ttk.Label(status, textvariable=self.status, width=52).grid(row=0, column=0, columnspan=3, sticky="w")
        ttk.Button(status, text="Install / Update", command=self.install).grid(row=1, column=0, pady=(8, 0), sticky="w")
        ttk.Button(status, text="Uninstall", command=self.uninstall).grid(row=1, column=1, pady=(8, 0), padx=6, sticky="w")
        ttk.Button(status, text="Launch SteamVR", command=self.launch).grid(row=1, column=2, pady=(8, 0), sticky="e")

        conn = ttk.LabelFrame(root, text="Connection", padding=8)
        conn.grid(row=1, column=0, sticky="ew", **pad)
        for i, (label, value) in enumerate(CONNECTIONS):
            ttk.Radiobutton(conn, text=label, value=value, variable=self.connection).grid(row=i // 2, column=i % 2, sticky="w", padx=(0, 20))
        ttk.Checkbutton(conn, text="Show connection icon", variable=self.show_connection).grid(row=2, column=0, columnspan=2, sticky="w", pady=(6, 0))

        dev = ttk.LabelFrame(root, text="Devices", padding=8)
        dev.grid(row=2, column=0, sticky="ew", **pad)
        ttk.Checkbutton(dev, text="Add left and right controllers", variable=self.enable_controllers).grid(row=0, column=0, columnspan=3, sticky="w")
        for i, (key, label) in enumerate([("hmdBatteryPercent", "Headset battery"), ("leftBatteryPercent", "Left battery"), ("rightBatteryPercent", "Right battery")]):
            var = self.battery[key]
            ttk.Label(dev, text=label, width=16).grid(row=i + 1, column=0, sticky="w")
            ttk.Scale(dev, from_=0, to=100, variable=var, length=240,
                      command=lambda v, var=var: var.set(int(float(v)))).grid(row=i + 1, column=1)
            ttk.Label(dev, textvariable=var, width=4, anchor="e").grid(row=i + 1, column=2)
        ttk.Checkbutton(dev, text="Charging", variable=self.charging).grid(row=4, column=0, sticky="w", pady=(4, 0))

        ttk.Label(dev, text="Refresh rate (Hz)").grid(row=5, column=0, sticky="w", pady=(6, 0))
        ttk.Combobox(dev, textvariable=self.frequency, values=FREQUENCIES, width=6).grid(row=5, column=1, sticky="w", pady=(6, 0))
        ttk.Label(dev, text="Headset name").grid(row=6, column=0, sticky="w", pady=(4, 0))
        ttk.Entry(dev, textvariable=self.hmd_model, width=30).grid(row=6, column=1, columnspan=2, sticky="w", pady=(4, 0))
        ttk.Label(dev, text="Controller name").grid(row=7, column=0, sticky="w", pady=(4, 0))
        ttk.Entry(dev, textvariable=self.controller_model, width=30).grid(row=7, column=1, columnspan=2, sticky="w", pady=(4, 0))

        adv = ttk.LabelFrame(root, text="SteamVR", padding=8)
        adv.grid(row=3, column=0, sticky="ew", **pad)
        ttk.Checkbutton(adv, text="Always use this driver as the headset (forcedDriver)", variable=self.forced).grid(row=0, column=0, sticky="w")

        bar = ttk.Frame(root)
        bar.grid(row=4, column=0, sticky="e", **pad)
        ttk.Button(bar, text="Save settings", command=self.save).grid(row=0, column=0)

    # ---- settings --------------------------------------------------------

    def settings_files(self):
        """Settings files to keep in sync: the installed copy and the source copy."""
        files = [SRC_DRIVER / SETTINGS_REL]
        if self.is_installed():
            files.insert(0, self.installed_dir / SETTINGS_REL)
        return [f for f in files if os.path.exists(lp(f))]

    def load_settings(self):
        files = self.settings_files()
        s = read_json(files[0]).get(SECTION, {}) if files else {}
        self.connection.set(s.get("connectionType", "usb"))
        self.show_connection.set(s.get("showConnection", True))
        self.enable_controllers.set(s.get("enableControllers", True))
        self.charging.set(s.get("charging", False))
        for key, var in self.battery.items():
            var.set(int(s.get(key, 100)))
        self.frequency.set(str(int(float(s.get("displayFrequency", 90)))))
        self.hmd_model.set(s.get("hmdModelNumber", "Steam Frame"))
        self.controller_model.set(s.get("controllerModelNumber", "Steam Frame Controller"))
        self.forced.set(self.read_forced() == DRIVER)

    def save(self):
        if steamvr_running() and not messagebox.askyesno(
                "SteamVR is running", "SteamVR only reads these settings when it starts.\n"
                "Save anyway? Restart SteamVR afterwards."):
            return
        try:
            frequency = float(self.frequency.get())
        except ValueError:
            messagebox.showerror("Invalid refresh rate", "Refresh rate must be a number.")
            return

        changes = {
            "connectionType": self.connection.get(),
            "showConnection": self.show_connection.get(),
            "enableControllers": self.enable_controllers.get(),
            "charging": self.charging.get(),
            "displayFrequency": frequency,
            "hmdModelNumber": self.hmd_model.get().strip() or "Steam Frame",
            "controllerModelNumber": self.controller_model.get().strip() or "Steam Frame Controller",
        }
        changes.update({k: v.get() for k, v in self.battery.items()})

        try:
            for path in self.settings_files():
                data = read_json(path)
                data.setdefault(SECTION, {}).update(changes)
                write_json(path, data)
            self.write_forced(self.forced.get())
        except (OSError, ValueError) as e:
            messagebox.showerror("Save failed", str(e))
            return
        messagebox.showinfo("Saved", "Settings saved. Restart SteamVR to apply them.")

    # ---- steamvr.vrsettings forcedDriver ---------------------------------

    def read_forced(self):
        try:
            return read_json(self.vrsettings).get("steamvr", {}).get("forcedDriver", "")
        except (OSError, ValueError):
            return ""

    def write_forced(self, enable):
        current = self.read_forced()
        if enable == (current == DRIVER):
            return
        if not os.path.exists(lp(self.vrsettings)):
            if not enable:
                return
            data = {}
        else:
            data = read_json(self.vrsettings)
            backup = self.vrsettings.with_name("steamvr.vrsettings.steamframe.bak")
            if not os.path.exists(lp(backup)):
                shutil.copy2(lp(self.vrsettings), lp(backup))
        steamvr = data.setdefault("steamvr", {})
        if enable:
            steamvr["forcedDriver"] = DRIVER
        else:
            steamvr.pop("forcedDriver", None)
        write_json(self.vrsettings, data, indent=3)

    # ---- install / uninstall --------------------------------------------

    def is_installed(self):
        return os.path.exists(lp(self.installed_dir / "driver.vrdrivermanifest"))

    def refresh_status(self):
        if not os.path.isdir(lp(self.steamvr / "bin")):
            self.status.set(f"SteamVR not found at {self.steamvr}")
        elif self.is_installed():
            self.status.set(f"Installed in {self.installed_dir}")
        else:
            self.status.set("Not installed")

    def install(self):
        dll = SRC_DRIVER / "bin" / "win64" / "driver_steamframe.dll"
        if not os.path.exists(lp(dll)):
            messagebox.showerror("Driver not built", f"Missing {dll}\nBuild the driver first (see README.md).")
            return
        if not os.path.isdir(lp(self.steamvr / "bin")):
            messagebox.showerror("SteamVR not found", f"SteamVR not found at {self.steamvr}")
            return
        if steamvr_running():
            messagebox.showwarning("SteamVR is running", "Close SteamVR first, then install.")
            return
        try:
            if os.path.exists(lp(self.installed_dir)):
                shutil.rmtree(lp(self.installed_dir))
            shutil.copytree(lp(SRC_DRIVER), lp(self.installed_dir))
        except OSError as e:
            messagebox.showerror("Install failed", f"{e}\n\nTry running this as administrator.")
            return
        self.refresh_status()
        messagebox.showinfo("Installed", f"Installed to {self.installed_dir}.\nStart SteamVR to see the Steam Frame.")

    def uninstall(self):
        if not self.is_installed():
            messagebox.showinfo("Not installed", "The driver isn't installed.")
            return
        if steamvr_running():
            messagebox.showwarning("SteamVR is running", "Close SteamVR first, then uninstall.")
            return
        if not messagebox.askyesno("Uninstall", f"Remove {self.installed_dir}?"):
            return
        try:
            shutil.rmtree(lp(self.installed_dir))
            if self.read_forced() == DRIVER:
                self.write_forced(False)
                self.forced.set(False)
        except OSError as e:
            messagebox.showerror("Uninstall failed", str(e))
            return
        self.refresh_status()
        messagebox.showinfo("Uninstalled", "Driver removed.")

    def launch(self):
        os.startfile("steam://rungameid/250820")


if __name__ == "__main__":
    App().mainloop()
