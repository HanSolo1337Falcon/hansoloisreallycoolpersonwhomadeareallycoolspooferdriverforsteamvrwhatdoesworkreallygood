# Removes the steamframe driver from SteamVR's drivers folder.
param(
    [string]$SteamVRPath = ""
)

$ErrorActionPreference = "Stop"

if (-not $SteamVRPath) {
    $steam = (Get-ItemProperty "HKCU:\Software\Valve\Steam" -ErrorAction SilentlyContinue).SteamPath
    if (-not $steam) { $steam = "C:\Program Files (x86)\Steam" }
    $SteamVRPath = Join-Path $steam "steamapps\common\SteamVR"
}

$dest = Join-Path $SteamVRPath "drivers\steamframe"
if (Test-Path $dest) {
    Remove-Item -Recurse -Force $dest
    Write-Host "Removed $dest"
} else {
    Write-Host "Not installed."
}
