#include "devices.h"

#include <cstring>
#include <memory>

#if defined( _WIN32 )
#define HMD_DLL_EXPORT extern "C" __declspec( dllexport )
#else
#define HMD_DLL_EXPORT extern "C" __attribute__( ( visibility( "default" ) ) )
#endif

using namespace vr;

namespace steamframe
{

class DeviceProvider : public IServerTrackedDeviceProvider
{
public:
	EVRInitError Init( IVRDriverContext *pDriverContext ) override
	{
		VR_INIT_SERVER_DRIVER_CONTEXT( pDriverContext );

		if ( !GetBool( "enable", true ) )
		{
			Log( "[steamframe] disabled in settings\n" );
			return VRInitError_Init_NoServerForBackgroundApp;
		}

		m_hmd = std::make_unique< HmdDevice >();
		VRServerDriverHost()->TrackedDeviceAdded( m_hmd->Serial().c_str(), TrackedDeviceClass_HMD, m_hmd.get() );

		if ( GetBool( "enableControllers", true ) )
		{
			m_left = std::make_unique< ControllerDevice >( TrackedControllerRole_LeftHand );
			m_right = std::make_unique< ControllerDevice >( TrackedControllerRole_RightHand );
			VRServerDriverHost()->TrackedDeviceAdded( m_left->Serial().c_str(), TrackedDeviceClass_Controller, m_left.get() );
			VRServerDriverHost()->TrackedDeviceAdded( m_right->Serial().c_str(), TrackedDeviceClass_Controller, m_right.get() );
		}

		if ( GetBool( "showConnection", true ) )
		{
			m_link = std::make_unique< LinkDevice >();
			VRServerDriverHost()->TrackedDeviceAdded( m_link->Serial().c_str(), TrackedDeviceClass_TrackingReference, m_link.get() );
		}

		Log( "[steamframe] driver initialized\n" );
		return VRInitError_None;
	}

	void Cleanup() override
	{
		m_hmd.reset();
		m_left.reset();
		m_right.reset();
		m_link.reset();
		VR_CLEANUP_SERVER_DRIVER_CONTEXT();
	}

	const char *const *GetInterfaceVersions() override { return k_InterfaceVersions; }

	void RunFrame() override
	{
		if ( m_hmd )
			m_hmd->RunFrame();
		if ( m_left )
			m_left->RunFrame();
		if ( m_right )
			m_right->RunFrame();
		if ( m_link )
			m_link->RunFrame();

		// Drain events (haptics etc.) so the queue doesn't back up.
		VREvent_t event;
		while ( VRServerDriverHost()->PollNextEvent( &event, sizeof( event ) ) )
		{
		}
	}

	bool ShouldBlockStandbyMode() override { return false; }
	void EnterStandby() override {}
	void LeaveStandby() override {}

private:
	std::unique_ptr< HmdDevice > m_hmd;
	std::unique_ptr< ControllerDevice > m_left, m_right;
	std::unique_ptr< LinkDevice > m_link;
};

static DeviceProvider g_provider;

} // namespace steamframe

HMD_DLL_EXPORT void *HmdDriverFactory( const char *pInterfaceName, int *pReturnCode )
{
	if ( 0 == strcmp( IServerTrackedDeviceProvider_Version, pInterfaceName ) )
		return &steamframe::g_provider;

	if ( pReturnCode )
		*pReturnCode = VRInitError_Init_InterfaceNotFound;
	return nullptr;
}
