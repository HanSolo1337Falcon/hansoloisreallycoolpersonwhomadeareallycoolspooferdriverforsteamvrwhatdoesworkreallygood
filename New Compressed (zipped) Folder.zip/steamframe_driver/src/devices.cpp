#include "devices.h"

#include <cstring>
#include <thread>

using namespace vr;

namespace steamframe
{

static void Respond( char *pchResponseBuffer, uint32_t unResponseBufferSize )
{
	if ( unResponseBufferSize >= 1 )
		pchResponseBuffer[ 0 ] = 0;
}

static void SetBattery( PropertyContainerHandle_t ulContainer, const char *pchPercentKey )
{
	CVRPropertyHelpers *props = VRProperties();
	props->SetBoolProperty( ulContainer, Prop_DeviceProvidesBatteryStatus_Bool, true );
	props->SetFloatProperty( ulContainer, Prop_DeviceBatteryPercentage_Float, GetInt( pchPercentKey, 100 ) / 100.0f );
	props->SetBoolProperty( ulContainer, Prop_DeviceIsCharging_Bool, GetBool( "charging", false ) );
	props->SetBoolProperty( ulContainer, Prop_DeviceCanPowerOff_Bool, true );
}

// ---------------------------------------------------------------------------
// HmdDevice
// ---------------------------------------------------------------------------

HmdDevice::HmdDevice()
{
	m_sSerial = GetString( "hmdSerialNumber", "SFRAME-HMD-0001" );
	m_bVirtualDisplay = GetBool( "virtualDisplay", true );
	m_nRenderWidth = GetInt( "renderWidth", 2160 );
	m_nRenderHeight = GetInt( "renderHeight", 2160 );
	if ( m_bVirtualDisplay )
	{
		// No real window: the "window" is just the side-by-side backbuffer the compositor fills.
		m_nWindowX = 0;
		m_nWindowY = 0;
		m_nWindowWidth = m_nRenderWidth * 2;
		m_nWindowHeight = m_nRenderHeight;
	}
	else
	{
		m_nWindowX = GetInt( "windowX", 0 );
		m_nWindowY = GetInt( "windowY", 0 );
		m_nWindowWidth = GetInt( "windowWidth", 1920 );
		m_nWindowHeight = GetInt( "windowHeight", 1080 );
	}
	m_flFovTan = GetFloat( "fovTan", 1.4f );
	float flFrequency = GetFloat( "displayFrequency", 90.0f );
	m_flFrameSeconds = 1.0 / ( flFrequency > 1.0f ? flFrequency : 90.0f );
	m_vsyncStart = Clock::now();
	m_pose = MakePose( 0.0, GetFloat( "hmdHeight", 1.6f ), 0.0 );
}

EVRInitError HmdDevice::Activate( uint32_t unObjectId )
{
	m_unObjectId = unObjectId;
	PropertyContainerHandle_t c = VRProperties()->TrackedDeviceToPropertyContainer( unObjectId );
	CVRPropertyHelpers *props = VRProperties();

	props->SetStringProperty( c, Prop_ManufacturerName_String, GetString( "manufacturer", "Valve" ).c_str() );
	props->SetStringProperty( c, Prop_ModelNumber_String, GetString( "hmdModelNumber", "Steam Frame" ).c_str() );
	props->SetStringProperty( c, Prop_TrackingSystemName_String, "steamframe" );
	props->SetStringProperty( c, Prop_SerialNumber_String, m_sSerial.c_str() );
	props->SetStringProperty( c, Prop_ControllerType_String, "frame_hmd" );
	props->SetStringProperty( c, Prop_InputProfilePath_String, "{frame_hmd}/input/input_profile.json" );
	props->SetStringProperty( c, Prop_RegisteredDeviceType_String, ( "steamframe/" + m_sSerial ).c_str() );

	props->SetFloatProperty( c, Prop_UserIpdMeters_Float, GetFloat( "ipd", 0.063f ) );
	props->SetFloatProperty( c, Prop_UserHeadToEyeDepthMeters_Float, 0.0f );
	props->SetFloatProperty( c, Prop_DisplayFrequency_Float, GetFloat( "displayFrequency", 90.0f ) );
	props->SetFloatProperty( c, Prop_SecondsFromVsyncToPhotons_Float, 0.011f );
	props->SetBoolProperty( c, Prop_IsOnDesktop_Bool, !m_bVirtualDisplay );
	props->SetInt32Property( c, Prop_HmdTrackingStyle_Int32, HmdTrackingStyle_InsideOutCameras );

	// The Frame is a wireless headset; report it as wired when the chosen link is USB.
	std::string sConnection = GetString( "connectionType", "usb" );
	props->SetBoolProperty( c, Prop_DeviceIsWireless_Bool, sConnection != "usb" );
	SetBattery( c, "hmdBatteryPercent" );

	StatusIcons icons;
	icons.off = "{vrlink}/icons/headset_steamframe_off.png";
	icons.searching = "{vrlink}/icons/headset_steamframe_searching.gif";
	icons.searchingAlert = "{vrlink}/icons/headset_steamframe_searching.gif";
	icons.ready = "{vrlink}/icons/headset_steamframe_ready.png";
	icons.readyAlert = "{vrlink}/icons/headset_steamframe_info.png";
	icons.notReady = "{vrlink}/icons/headset_steamframe_error.png";
	icons.standby = "{vrlink}/icons/headset_steamframe_off.png";
	icons.alertLow = "{vrlink}/icons/headset_steamframe_ready_low.png";
	icons.standbyAlert = "{vrlink}/icons/headset_steamframe_off.png";
	ApplyIcons( c, icons );

	VRInputComponentHandle_t h;
	VRDriverInput()->CreateBooleanComponent( c, "/input/system/click", &h );
	VRDriverInput()->CreateBooleanComponent( c, "/input/volume_up/click", &h );
	VRDriverInput()->CreateBooleanComponent( c, "/input/volume_down/click", &h );

	Log( "[steamframe] HMD activated as device %u (%s)\n", unObjectId, m_sSerial.c_str() );
	return VRInitError_None;
}

void HmdDevice::Deactivate()
{
	m_unObjectId = k_unTrackedDeviceIndexInvalid;
}

void *HmdDevice::GetComponent( const char *pchComponentNameAndVersion )
{
	if ( strcmp( pchComponentNameAndVersion, IVRDisplayComponent_Version ) == 0 )
		return static_cast< IVRDisplayComponent * >( this );
	if ( m_bVirtualDisplay && strcmp( pchComponentNameAndVersion, IVRVirtualDisplay_Version ) == 0 )
		return static_cast< IVRVirtualDisplay * >( this );
	return nullptr;
}

void HmdDevice::DebugRequest( const char *, char *pchResponseBuffer, uint32_t unResponseBufferSize )
{
	Respond( pchResponseBuffer, unResponseBufferSize );
}

DriverPose_t HmdDevice::GetPose()
{
	return m_pose;
}

void HmdDevice::RunFrame()
{
	if ( m_unObjectId != k_unTrackedDeviceIndexInvalid )
		VRServerDriverHost()->TrackedDevicePoseUpdated( m_unObjectId, m_pose, sizeof( DriverPose_t ) );
}

void HmdDevice::GetWindowBounds( int32_t *pnX, int32_t *pnY, uint32_t *pnWidth, uint32_t *pnHeight )
{
	*pnX = m_nWindowX;
	*pnY = m_nWindowY;
	*pnWidth = m_nWindowWidth;
	*pnHeight = m_nWindowHeight;
}

void HmdDevice::GetRecommendedRenderTargetSize( uint32_t *pnWidth, uint32_t *pnHeight )
{
	*pnWidth = m_nRenderWidth;
	*pnHeight = m_nRenderHeight;
}

void HmdDevice::GetEyeOutputViewport( EVREye eEye, uint32_t *pnX, uint32_t *pnY, uint32_t *pnWidth, uint32_t *pnHeight )
{
	*pnY = 0;
	*pnWidth = m_nWindowWidth / 2;
	*pnHeight = m_nWindowHeight;
	*pnX = ( eEye == Eye_Left ) ? 0 : m_nWindowWidth / 2;
}

void HmdDevice::GetProjectionRaw( EVREye, float *pfLeft, float *pfRight, float *pfTop, float *pfBottom )
{
	*pfLeft = -m_flFovTan;
	*pfRight = m_flFovTan;
	*pfTop = -m_flFovTan;
	*pfBottom = m_flFovTan;
}

DistortionCoordinates_t HmdDevice::ComputeDistortion( EVREye, float fU, float fV )
{
	DistortionCoordinates_t coords;
	coords.rfRed[ 0 ] = coords.rfGreen[ 0 ] = coords.rfBlue[ 0 ] = fU;
	coords.rfRed[ 1 ] = coords.rfGreen[ 1 ] = coords.rfBlue[ 1 ] = fV;
	return coords;
}

bool HmdDevice::ComputeInverseDistortion( HmdVector2_t *, EVREye, uint32_t, float, float )
{
	return false;
}

void HmdDevice::Present( const PresentInfo_t *pPresentInfo, uint32_t unPresentInfoSize )
{
	if ( pPresentInfo && unPresentInfoSize >= sizeof( PresentInfo_t ) )
		m_nLastPresentedFrame = pPresentInfo->nFrameId;
}

void HmdDevice::WaitForPresent()
{
	// Pretend the frame scans out on the next simulated vsync.
	auto elapsed = std::chrono::duration< double >( Clock::now() - m_vsyncStart ).count();
	uint64_t nextVsync = static_cast< uint64_t >( elapsed / m_flFrameSeconds ) + 1;
	auto target = m_vsyncStart + std::chrono::duration_cast< Clock::duration >( std::chrono::duration< double >( nextVsync * m_flFrameSeconds ) );
	std::this_thread::sleep_until( target );
}

bool HmdDevice::GetTimeSinceLastVsync( float *pfSecondsSinceLastVsync, uint64_t *pulFrameCounter )
{
	double elapsed = std::chrono::duration< double >( Clock::now() - m_vsyncStart ).count();
	uint64_t frames = static_cast< uint64_t >( elapsed / m_flFrameSeconds );
	*pfSecondsSinceLastVsync = static_cast< float >( elapsed - frames * m_flFrameSeconds );
	*pulFrameCounter = frames;
	return true;
}

// ---------------------------------------------------------------------------
// ControllerDevice
// ---------------------------------------------------------------------------

ControllerDevice::ControllerDevice( ETrackedControllerRole eRole )
	: m_eRole( eRole )
{
	bool bLeft = eRole == TrackedControllerRole_LeftHand;
	m_sSerial = GetString( bLeft ? "leftSerialNumber" : "rightSerialNumber", bLeft ? "SFRAME-CTRL-L" : "SFRAME-CTRL-R" );
	float flHeight = GetFloat( "hmdHeight", 1.6f );
	m_pose = MakePose( bLeft ? -0.2 : 0.2, flHeight - 0.4, -0.35 );
}

EVRInitError ControllerDevice::Activate( uint32_t unObjectId )
{
	m_unObjectId = unObjectId;
	PropertyContainerHandle_t c = VRProperties()->TrackedDeviceToPropertyContainer( unObjectId );
	CVRPropertyHelpers *props = VRProperties();
	bool bLeft = m_eRole == TrackedControllerRole_LeftHand;
	const char *pchSide = bLeft ? "left" : "right";

	props->SetStringProperty( c, Prop_ManufacturerName_String, GetString( "manufacturer", "Valve" ).c_str() );
	props->SetStringProperty( c, Prop_ModelNumber_String, GetString( "controllerModelNumber", "Steam Frame Controller" ).c_str() );
	props->SetStringProperty( c, Prop_TrackingSystemName_String, "steamframe" );
	props->SetStringProperty( c, Prop_SerialNumber_String, m_sSerial.c_str() );
	props->SetStringProperty( c, Prop_ControllerType_String, "frame_controller" );
	props->SetStringProperty( c, Prop_InputProfilePath_String, "{frame_controller}/input/frame_controller_profile.json" );
	props->SetStringProperty( c, Prop_RenderModelName_String,
		bLeft ? "{frame_controller}frame_controller_left" : "{frame_controller}frame_controller_right" );
	props->SetStringProperty( c, Prop_RegisteredDeviceType_String, ( "steamframe/" + m_sSerial ).c_str() );
	props->SetInt32Property( c, Prop_ControllerRoleHint_Int32, m_eRole );
	props->SetInt32Property( c, Prop_DeviceClass_Int32, TrackedDeviceClass_Controller );

	props->SetBoolProperty( c, Prop_DeviceIsWireless_Bool, true );
	props->SetStringProperty( c, Prop_ConnectedWirelessDongle_String, GetString( "hmdSerialNumber", "SFRAME-HMD-0001" ).c_str() );
	SetBattery( c, bLeft ? "leftBatteryPercent" : "rightBatteryPercent" );

	std::string base = std::string( "{frame_controller}/icons/" ) + pchSide + "_frame_controller_";
	StatusIcons icons;
	icons.off = base + "off.png";
	icons.searching = base + "seaching.gif"; // sic: Valve's file name
	icons.searchingAlert = base + "seaching.gif";
	icons.ready = base + "ready.png";
	icons.readyAlert = base + "info.png";
	icons.notReady = base + "error.png";
	icons.standby = base + "off.png";
	icons.alertLow = base + "ready_low.png";
	icons.standbyAlert = base + "off.png";
	ApplyIcons( c, icons );

	// Input components matching frame_controller_profile.json.
	IVRDriverInput *input = VRDriverInput();
	auto addBool = [ & ]( const char *pchPath ) {
		VRInputComponentHandle_t h;
		input->CreateBooleanComponent( c, pchPath, &h );
		m_components.push_back( h );
	};
	auto addScalar = [ & ]( const char *pchPath, EVRScalarUnits eUnits ) {
		VRInputComponentHandle_t h;
		input->CreateScalarComponent( c, pchPath, &h, VRScalarType_Absolute, eUnits );
		m_components.push_back( h );
	};

	const char *aButtons[] = { "system", "bumper" };
	const char *aRight[] = { "menu", "a", "b", "x", "y" };
	const char *aLeft[] = { "view", "dpad_up", "dpad_right", "dpad_down", "dpad_left" };
	std::vector< const char * > buttons( std::begin( aButtons ), std::end( aButtons ) );
	if ( bLeft )
		buttons.insert( buttons.end(), std::begin( aLeft ), std::end( aLeft ) );
	else
		buttons.insert( buttons.end(), std::begin( aRight ), std::end( aRight ) );
	for ( const char *pchName : buttons )
	{
		addBool( ( std::string( "/input/" ) + pchName + "/click" ).c_str() );
		addBool( ( std::string( "/input/" ) + pchName + "/touch" ).c_str() );
	}

	for ( const char *pchName : { "trigger", "grip" } )
	{
		addBool( ( std::string( "/input/" ) + pchName + "/click" ).c_str() );
		addBool( ( std::string( "/input/" ) + pchName + "/touch" ).c_str() );
		addScalar( ( std::string( "/input/" ) + pchName + "/value" ).c_str(), VRScalarUnits_NormalizedOneSided );
	}

	addBool( "/input/thumbstick/click" );
	addBool( "/input/thumbstick/touch" );
	addScalar( "/input/thumbstick/x", VRScalarUnits_NormalizedTwoSided );
	addScalar( "/input/thumbstick/y", VRScalarUnits_NormalizedTwoSided );
	addBool( "/input/thumbrest/touch" );

	VRInputComponentHandle_t hHaptic;
	input->CreateHapticComponent( c, "/output/haptic", &hHaptic );

	Log( "[steamframe] %s controller activated as device %u (%s)\n", pchSide, unObjectId, m_sSerial.c_str() );
	return VRInitError_None;
}

void ControllerDevice::Deactivate()
{
	m_unObjectId = k_unTrackedDeviceIndexInvalid;
	m_components.clear();
}

void ControllerDevice::DebugRequest( const char *, char *pchResponseBuffer, uint32_t unResponseBufferSize )
{
	Respond( pchResponseBuffer, unResponseBufferSize );
}

void ControllerDevice::RunFrame()
{
	if ( m_unObjectId != k_unTrackedDeviceIndexInvalid )
		VRServerDriverHost()->TrackedDevicePoseUpdated( m_unObjectId, m_pose, sizeof( DriverPose_t ) );
}

// ---------------------------------------------------------------------------
// LinkDevice
// ---------------------------------------------------------------------------

LinkDevice::LinkDevice()
{
	m_sSerial = GetString( "linkSerialNumber", "SFRAME-LINK-0001" );
	m_sConnection = GetString( "connectionType", "usb" );
	if ( m_sConnection != "usb" && m_sConnection != "dongle" && m_sConnection != "wired_to_router" && m_sConnection != "wireless_to_router" )
		m_sConnection = "usb";
	// Off to the side on the floor so it doesn't sit in view.
	m_pose = MakePose( 1.5, 0.0, 1.5 );
}

EVRInitError LinkDevice::Activate( uint32_t unObjectId )
{
	m_unObjectId = unObjectId;
	PropertyContainerHandle_t c = VRProperties()->TrackedDeviceToPropertyContainer( unObjectId );
	CVRPropertyHelpers *props = VRProperties();

	const char *pchModel = m_sConnection == "usb"                ? "Steam Frame USB Link"
	                       : m_sConnection == "dongle"           ? "Steam Frame Wireless Adapter"
	                       : m_sConnection == "wired_to_router"  ? "Steam Frame Link (Wired Router)"
	                                                             : "Steam Frame Link (Wireless Router)";

	props->SetStringProperty( c, Prop_ManufacturerName_String, GetString( "manufacturer", "Valve" ).c_str() );
	props->SetStringProperty( c, Prop_ModelNumber_String, pchModel );
	props->SetStringProperty( c, Prop_TrackingSystemName_String, "steamframe" );
	props->SetStringProperty( c, Prop_SerialNumber_String, m_sSerial.c_str() );
	props->SetStringProperty( c, Prop_RenderModelName_String, "" );
	props->SetStringProperty( c, Prop_ModeLabel_String, m_sConnection == "usb" ? "USB" : "LINK" );
	props->SetBoolProperty( c, Prop_DeviceIsWireless_Bool, m_sConnection != "usb" && m_sConnection != "wired_to_router" );
	props->SetFloatProperty( c, Prop_FieldOfViewLeftDegrees_Float, 0.0f );
	props->SetFloatProperty( c, Prop_FieldOfViewRightDegrees_Float, 0.0f );
	props->SetFloatProperty( c, Prop_FieldOfViewTopDegrees_Float, 0.0f );
	props->SetFloatProperty( c, Prop_FieldOfViewBottomDegrees_Float, 0.0f );
	props->SetFloatProperty( c, Prop_TrackingRangeMinimumMeters_Float, 0.0f );
	props->SetFloatProperty( c, Prop_TrackingRangeMaximumMeters_Float, 0.0f );

	std::string base = "{vrlink}/icons/link_" + m_sConnection;
	// Only the dongle has an animated "searching" icon.
	std::string searching = m_sConnection == "dongle" ? "{vrlink}/icons/link_dongle_searching.gif" : base + "_off.png";
	StatusIcons icons;
	icons.off = base + "_off.png";
	icons.searching = searching;
	icons.searchingAlert = searching;
	icons.ready = base + ".png";
	icons.readyAlert = base + ".png";
	icons.notReady = base + "_off.png";
	icons.standby = base + "_off.png";
	icons.alertLow = base + ".png";
	icons.standbyAlert = base + "_off.png";
	ApplyIcons( c, icons );
	// SteamVR shows this icon before a tracking reference has reported in.
	props->SetStringProperty( c, Prop_NamedIconPathTrackingReferenceDeviceOff_String, icons.off.c_str() );

	Log( "[steamframe] connection indicator (%s) activated as device %u\n", m_sConnection.c_str(), unObjectId );
	return VRInitError_None;
}

void LinkDevice::DebugRequest( const char *, char *pchResponseBuffer, uint32_t unResponseBufferSize )
{
	Respond( pchResponseBuffer, unResponseBufferSize );
}

void LinkDevice::RunFrame()
{
	if ( m_unObjectId != k_unTrackedDeviceIndexInvalid )
		VRServerDriverHost()->TrackedDevicePoseUpdated( m_unObjectId, m_pose, sizeof( DriverPose_t ) );
}

} // namespace steamframe
