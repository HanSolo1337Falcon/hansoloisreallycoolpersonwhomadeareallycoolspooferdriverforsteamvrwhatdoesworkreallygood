#pragma once

#include <openvr_driver.h>
#include <cstdarg>
#include <cstdio>
#include <string>

namespace steamframe
{
static const char *k_pchSection = "driver_steamframe";

inline std::string GetString( const char *pchKey, const char *pchDefault )
{
	char buf[ 1024 ];
	vr::EVRSettingsError err = vr::VRSettingsError_None;
	vr::VRSettings()->GetString( k_pchSection, pchKey, buf, sizeof( buf ), &err );
	return ( err == vr::VRSettingsError_None && buf[ 0 ] ) ? std::string( buf ) : std::string( pchDefault );
}

inline int32_t GetInt( const char *pchKey, int32_t nDefault )
{
	vr::EVRSettingsError err = vr::VRSettingsError_None;
	int32_t v = vr::VRSettings()->GetInt32( k_pchSection, pchKey, &err );
	return err == vr::VRSettingsError_None ? v : nDefault;
}

inline float GetFloat( const char *pchKey, float flDefault )
{
	vr::EVRSettingsError err = vr::VRSettingsError_None;
	float v = vr::VRSettings()->GetFloat( k_pchSection, pchKey, &err );
	return err == vr::VRSettingsError_None ? v : flDefault;
}

inline bool GetBool( const char *pchKey, bool bDefault )
{
	vr::EVRSettingsError err = vr::VRSettingsError_None;
	bool v = vr::VRSettings()->GetBool( k_pchSection, pchKey, &err );
	return err == vr::VRSettingsError_None ? v : bDefault;
}

inline void Log( const char *pchFormat, ... )
{
	char buf[ 1024 ];
	va_list args;
	va_start( args, pchFormat );
	vsnprintf( buf, sizeof( buf ), pchFormat, args );
	va_end( args );
	vr::VRDriverLog()->Log( buf );
}

// Fills in the nine status-window icon properties for a device.
struct StatusIcons
{
	std::string off, searching, searchingAlert, ready, readyAlert, notReady, standby, alertLow, standbyAlert;
};

inline void ApplyIcons( vr::PropertyContainerHandle_t ulContainer, const StatusIcons &icons )
{
	vr::CVRPropertyHelpers *props = vr::VRProperties();
	props->SetStringProperty( ulContainer, vr::Prop_NamedIconPathDeviceOff_String, icons.off.c_str() );
	props->SetStringProperty( ulContainer, vr::Prop_NamedIconPathDeviceSearching_String, icons.searching.c_str() );
	props->SetStringProperty( ulContainer, vr::Prop_NamedIconPathDeviceSearchingAlert_String, icons.searchingAlert.c_str() );
	props->SetStringProperty( ulContainer, vr::Prop_NamedIconPathDeviceReady_String, icons.ready.c_str() );
	props->SetStringProperty( ulContainer, vr::Prop_NamedIconPathDeviceReadyAlert_String, icons.readyAlert.c_str() );
	props->SetStringProperty( ulContainer, vr::Prop_NamedIconPathDeviceNotReady_String, icons.notReady.c_str() );
	props->SetStringProperty( ulContainer, vr::Prop_NamedIconPathDeviceStandby_String, icons.standby.c_str() );
	props->SetStringProperty( ulContainer, vr::Prop_NamedIconPathDeviceAlertLow_String, icons.alertLow.c_str() );
	props->SetStringProperty( ulContainer, vr::Prop_NamedIconPathDeviceStandbyAlert_String, icons.standbyAlert.c_str() );
}

inline vr::DriverPose_t MakePose( double x, double y, double z )
{
	vr::DriverPose_t pose = {};
	pose.qWorldFromDriverRotation.w = 1.0;
	pose.qDriverFromHeadRotation.w = 1.0;
	pose.qRotation.w = 1.0;
	pose.vecPosition[ 0 ] = x;
	pose.vecPosition[ 1 ] = y;
	pose.vecPosition[ 2 ] = z;
	pose.poseIsValid = true;
	pose.result = vr::TrackingResult_Running_OK;
	pose.deviceIsConnected = true;
	return pose;
}
} // namespace steamframe
