#pragma once

#include "settings.h"

#include <openvr_driver.h>
#include <atomic>
#include <chrono>
#include <string>
#include <vector>

namespace steamframe
{

// The Steam Frame headset. Shows the Frame icon in the status window.
// By default it is a virtual display (like a wireless headset): the compositor
// hands it frames and nothing appears on the desktop. With virtualDisplay off
// it falls back to a desktop window, which SteamVR flags as "Headset Error (-202)".
class HmdDevice : public vr::ITrackedDeviceServerDriver, public vr::IVRDisplayComponent, public vr::IVRVirtualDisplay
{
public:
	HmdDevice();

	const std::string &Serial() const { return m_sSerial; }
	void RunFrame();

	// ITrackedDeviceServerDriver
	vr::EVRInitError Activate( uint32_t unObjectId ) override;
	void Deactivate() override;
	void EnterStandby() override {}
	void *GetComponent( const char *pchComponentNameAndVersion ) override;
	void DebugRequest( const char *, char *pchResponseBuffer, uint32_t unResponseBufferSize ) override;
	vr::DriverPose_t GetPose() override;

	// IVRDisplayComponent
	void GetWindowBounds( int32_t *pnX, int32_t *pnY, uint32_t *pnWidth, uint32_t *pnHeight ) override;
	bool IsDisplayOnDesktop() override { return !m_bVirtualDisplay; }
	bool IsDisplayRealDisplay() override { return false; }
	void GetRecommendedRenderTargetSize( uint32_t *pnWidth, uint32_t *pnHeight ) override;
	void GetEyeOutputViewport( vr::EVREye eEye, uint32_t *pnX, uint32_t *pnY, uint32_t *pnWidth, uint32_t *pnHeight ) override;
	void GetProjectionRaw( vr::EVREye eEye, float *pfLeft, float *pfRight, float *pfTop, float *pfBottom ) override;
	vr::DistortionCoordinates_t ComputeDistortion( vr::EVREye eEye, float fU, float fV ) override;
	bool ComputeInverseDistortion( vr::HmdVector2_t *pResult, vr::EVREye eEye, uint32_t unChannel, float fU, float fV ) override;

	// IVRVirtualDisplay: frames are accepted and dropped, paced to displayFrequency.
	void Present( const vr::PresentInfo_t *pPresentInfo, uint32_t unPresentInfoSize ) override;
	void WaitForPresent() override;
	bool GetTimeSinceLastVsync( float *pfSecondsSinceLastVsync, uint64_t *pulFrameCounter ) override;

private:
	using Clock = std::chrono::steady_clock;

	uint32_t m_unObjectId = vr::k_unTrackedDeviceIndexInvalid;
	std::string m_sSerial;
	bool m_bVirtualDisplay;
	int32_t m_nWindowX, m_nWindowY, m_nWindowWidth, m_nWindowHeight;
	int32_t m_nRenderWidth, m_nRenderHeight;
	float m_flFovTan;
	double m_flFrameSeconds;
	Clock::time_point m_vsyncStart;
	std::atomic< uint64_t > m_nLastPresentedFrame{ 0 };
	vr::DriverPose_t m_pose;
};

// One Steam Frame controller. Uses SteamVR's own frame_controller input
// profile, render models and status icons.
class ControllerDevice : public vr::ITrackedDeviceServerDriver
{
public:
	explicit ControllerDevice( vr::ETrackedControllerRole eRole );

	const std::string &Serial() const { return m_sSerial; }
	void RunFrame();

	vr::EVRInitError Activate( uint32_t unObjectId ) override;
	void Deactivate() override;
	void EnterStandby() override {}
	void *GetComponent( const char * ) override { return nullptr; }
	void DebugRequest( const char *, char *pchResponseBuffer, uint32_t unResponseBufferSize ) override;
	vr::DriverPose_t GetPose() override { return m_pose; }

private:
	vr::ETrackedControllerRole m_eRole;
	uint32_t m_unObjectId = vr::k_unTrackedDeviceIndexInvalid;
	std::string m_sSerial;
	vr::DriverPose_t m_pose;
	std::vector< vr::VRInputComponentHandle_t > m_components;
};

// Status-window entry that shows how the headset is connected
// (USB, wireless dongle, or via a router) using SteamVR's link icons.
class LinkDevice : public vr::ITrackedDeviceServerDriver
{
public:
	LinkDevice();

	const std::string &Serial() const { return m_sSerial; }
	void RunFrame();

	vr::EVRInitError Activate( uint32_t unObjectId ) override;
	void Deactivate() override { m_unObjectId = vr::k_unTrackedDeviceIndexInvalid; }
	void EnterStandby() override {}
	void *GetComponent( const char * ) override { return nullptr; }
	void DebugRequest( const char *, char *pchResponseBuffer, uint32_t unResponseBufferSize ) override;
	vr::DriverPose_t GetPose() override { return m_pose; }

private:
	uint32_t m_unObjectId = vr::k_unTrackedDeviceIndexInvalid;
	std::string m_sSerial;
	std::string m_sConnection;
	vr::DriverPose_t m_pose;
};

} // namespace steamframe
