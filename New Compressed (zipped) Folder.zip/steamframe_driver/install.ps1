# Copies the steamframe driver into SteamVR's drivers folder.
# Close SteamVR before running.
param(
    [string]$SteamVRPath = ""
)

$ErrorActionPreference = "Stop"

if (-not $SteamVRPath) {
    $steam = (Get-ItemProperty "HKCU:\Software\Valve\Steam" -ErrorAction SilentlyContinue).SteamPath
    if (-not $steam) { $steam = "C:\Program Files (x86)\Steam" }
    $SteamVRPath = Join-Path $steam "steamapps\common\SteamVR"
}
if (-not (Test-Path (Join-Path $SteamVRPath "bin"))) {
    throw "SteamVR not found at '$SteamVRPath'. Pass -SteamVRPath <folder>."
}

$src = Join-Path $PSScriptRoot "steamframe"
$dll = Join-Path $src "bin\win64\driver_steamframe.dll"
if (-not (Test-Path $dll)) { throw "Build the driver first (driver_steamframe.dll missing)." }

$dest = Join-Path $SteamVRPath "drivers\steamframe"
if (Test-Path $dest) { Remove-Item -Recurse -Force $dest }
Copy-Item -Recurse $src $dest
Write-Host "Installed to $dest"
Write-Host "Start SteamVR. If another headset is plugged in, unplug it or set"
Write-Host "  steamvr.forcedDriver = ""steamframe""  in steamvr.vrsettings."
